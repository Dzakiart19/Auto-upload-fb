import { Mastra } from '@mastra/core';
import { MastraError } from '@mastra/core/error';
import { PinoLogger } from '@mastra/loggers';
import { MastraLogger, LogLevel } from '@mastra/core/logger';
import pino from 'pino';
import { MCPServer } from '@mastra/mcp';
import { Inngest, NonRetriableError } from 'inngest';
import { z } from 'zod';
import { LibSQLStore } from '@mastra/libsql';
import { realtimeMiddleware } from '@inngest/realtime';
import { serve, init } from '@mastra/inngest';
import { registerApiRoute as registerApiRoute$1 } from '@mastra/core/server';
import { Agent } from '@mastra/core/agent';
import { Memory } from '@mastra/memory';
import { createTool } from '@mastra/core/tools';
import * as fs from 'fs';
import fs__default from 'fs';
import * as path from 'path';
import { execSync } from 'child_process';
import FormData from 'form-data';
import axios from 'axios';
import { createOpenAI } from '@ai-sdk/openai';

const sharedPostgresStorage = new LibSQLStore({
  url: "file:mastra.db"
});

const inngest = new Inngest(
  process.env.NODE_ENV === "production" ? {
    id: "replit-agent-workflow",
    name: "Replit Agent Workflow System"
  } : {
    id: "mastra",
    baseUrl: "http://localhost:3000",
    isDev: true,
    middleware: [realtimeMiddleware()]
  }
);

const {
  createWorkflow: originalCreateWorkflow,
  createStep} = init(inngest);
function createWorkflow(params) {
  return originalCreateWorkflow({
    ...params,
    retryConfig: {
      attempts: process.env.NODE_ENV === "production" ? 3 : 0,
      ...params.retryConfig ?? {}
    }
  });
}
const inngestFunctions = [];
function registerApiRoute(...args) {
  const [path, options] = args;
  if (typeof options !== "object") {
    return registerApiRoute$1(...args);
  }
  const pathWithoutSlash = path.replace(/^\/+/, "");
  const pathWithoutApi = pathWithoutSlash.startsWith("api/") ? pathWithoutSlash.substring(4) : pathWithoutSlash;
  const connectorName = pathWithoutApi.split("/")[0];
  inngestFunctions.push(
    inngest.createFunction(
      {
        id: `api-${connectorName}`,
        name: path
      },
      {
        // Match the event pattern created by createWebhook: event/api.webhooks.{connector-name}.action
        event: `event/api.webhooks.${connectorName}.action`
      },
      async ({ event, step }) => {
        await step.run("forward request to Mastra", async () => {
          const response = await fetch(`http://localhost:5000${path}`, {
            method: event.data.method,
            headers: event.data.headers,
            body: event.data.body
          });
          if (!response.ok) {
            if (response.status >= 500 && response.status < 600 || response.status == 429 || response.status == 408) {
              throw new Error(
                `Failed to forward request to Mastra: ${response.statusText}`
              );
            } else {
              throw new NonRetriableError(
                `Failed to forward request to Mastra: ${response.statusText}`
              );
            }
          }
        });
      }
    )
  );
  return registerApiRoute$1(...args);
}
function inngestServe({
  mastra,
  inngest: inngest2
}) {
  let serveHost = void 0;
  if (process.env.NODE_ENV === "production") {
    if (process.env.REPLIT_DOMAINS) {
      serveHost = `https://${process.env.REPLIT_DOMAINS.split(",")[0]}`;
    }
  } else {
    serveHost = "http://localhost:5000";
  }
  return serve({
    mastra,
    inngest: inngest2,
    functions: inngestFunctions,
    registerOptions: { serveHost }
  });
}

const telegramDownloadVideo = createTool({
  id: "telegram-download-video",
  description: "Download video file from Telegram using file_id",
  inputSchema: z.object({
    fileId: z.string().describe("Telegram file_id of the video"),
    fileName: z.string().optional().describe("Custom file name for the downloaded video")
  }),
  outputSchema: z.object({
    success: z.boolean(),
    filePath: z.string().optional(),
    fileSize: z.number().optional(),
    error: z.string().optional()
  }),
  execute: async ({ context, mastra }) => {
    const logger = mastra?.getLogger();
    logger?.info("\u{1F527} [telegramDownloadVideo] Starting execution with params:", context);
    const token = process.env.TELEGRAM_BOT_TOKEN?.trim();
    if (!token) {
      logger?.error("\u274C [telegramDownloadVideo] TELEGRAM_BOT_TOKEN not found");
      return {
        success: false,
        error: "TELEGRAM_BOT_TOKEN tidak ditemukan di environment variables"
      };
    }
    try {
      logger?.info("\u{1F4DD} [telegramDownloadVideo] Getting file path from Telegram...");
      const fileInfoResponse = await fetch(
        `https://api.telegram.org/bot${token}/getFile?file_id=${context.fileId}`
      );
      if (!fileInfoResponse.ok) {
        const errorData = await fileInfoResponse.json();
        logger?.error("\u274C [telegramDownloadVideo] Failed to get file info:", errorData);
        return {
          success: false,
          error: `Gagal mendapatkan info file: ${JSON.stringify(errorData)}`
        };
      }
      const fileInfo = await fileInfoResponse.json();
      if (!fileInfo.ok || !fileInfo.result.file_path) {
        logger?.error("\u274C [telegramDownloadVideo] Invalid file info response:", fileInfo);
        return {
          success: false,
          error: "File path tidak ditemukan dalam response Telegram"
        };
      }
      const filePath = fileInfo.result.file_path;
      const fileSize = fileInfo.result.file_size || 0;
      const fileExtension = filePath.split(".").pop() || "mp4";
      logger?.info("\u{1F4DD} [telegramDownloadVideo] Downloading file from Telegram...", {
        filePath,
        fileSize,
        fileExtension
      });
      const downloadUrl = `https://api.telegram.org/file/bot${token}/${filePath}`;
      const downloadResponse = await fetch(downloadUrl);
      if (!downloadResponse.ok) {
        logger?.error("\u274C [telegramDownloadVideo] Failed to download file");
        return {
          success: false,
          error: `Gagal mendownload file: ${downloadResponse.statusText}`
        };
      }
      const buffer = await downloadResponse.arrayBuffer();
      const bufferData = Buffer.from(buffer);
      logger?.info("\u{1F4CA} [telegramDownloadVideo] Downloaded buffer info:", {
        byteLength: buffer.byteLength,
        bufferLength: bufferData.length,
        expectedSize: fileSize
      });
      if (bufferData.length === 0) {
        logger?.error("\u274C [telegramDownloadVideo] Downloaded buffer is empty!");
        return {
          success: false,
          error: "File yang di-download kosong (0 bytes)"
        };
      }
      if (fileSize > 0 && Math.abs(bufferData.length - fileSize) > 1e3) {
        logger?.warn("\u26A0\uFE0F [telegramDownloadVideo] Size mismatch:", {
          expected: fileSize,
          actual: bufferData.length,
          difference: Math.abs(bufferData.length - fileSize)
        });
      }
      const baseFileName = context.fileName || `video_${Date.now()}`;
      const fileName = baseFileName.includes(".") ? baseFileName : `${baseFileName}.${fileExtension}`;
      const tmpDir = "/tmp/telegram_videos";
      if (!fs.existsSync(tmpDir)) {
        fs.mkdirSync(tmpDir, { recursive: true });
      }
      const localFilePath = path.join(tmpDir, fileName);
      fs.writeFileSync(localFilePath, bufferData);
      const stats = fs.statSync(localFilePath);
      logger?.info("\u2705 [telegramDownloadVideo] Video downloaded successfully:", {
        localFilePath,
        fileSize: stats.size,
        expectedSize: fileSize,
        bufferSize: bufferData.length,
        fileExtension
      });
      if (stats.size === 0) {
        logger?.error("\u274C [telegramDownloadVideo] Written file is empty!");
        return {
          success: false,
          error: "File tersimpan dengan ukuran 0 bytes"
        };
      }
      if (stats.size < 10240) {
        logger?.warn("\u26A0\uFE0F [telegramDownloadVideo] File size is very small (< 10KB), might be corrupt:", stats.size);
      }
      return {
        success: true,
        filePath: localFilePath,
        fileSize: stats.size
      };
    } catch (error) {
      logger?.error("\u274C [telegramDownloadVideo] Error:", error);
      return {
        success: false,
        error: `Error: ${error.message}`
      };
    }
  }
});

const telegramDownloadPhoto = createTool({
  id: "telegram-download-photo",
  description: "Download photo file from Telegram using file_id",
  inputSchema: z.object({
    fileId: z.string().describe("Telegram file_id of the photo"),
    fileName: z.string().optional().describe("Custom file name for the downloaded photo")
  }),
  outputSchema: z.object({
    success: z.boolean(),
    filePath: z.string().optional(),
    fileSize: z.number().optional(),
    error: z.string().optional()
  }),
  execute: async ({ context, mastra }) => {
    const logger = mastra?.getLogger();
    logger?.info("\u{1F527} [telegramDownloadPhoto] Starting execution with params:", context);
    const token = process.env.TELEGRAM_BOT_TOKEN?.trim();
    if (!token) {
      logger?.error("\u274C [telegramDownloadPhoto] TELEGRAM_BOT_TOKEN not found");
      return {
        success: false,
        error: "TELEGRAM_BOT_TOKEN tidak ditemukan di environment variables"
      };
    }
    try {
      logger?.info("\u{1F4DD} [telegramDownloadPhoto] Getting file path from Telegram...");
      const fileInfoResponse = await fetch(
        `https://api.telegram.org/bot${token}/getFile?file_id=${context.fileId}`
      );
      if (!fileInfoResponse.ok) {
        const errorData = await fileInfoResponse.json();
        logger?.error("\u274C [telegramDownloadPhoto] Failed to get file info:", errorData);
        return {
          success: false,
          error: `Gagal mendapatkan info file: ${JSON.stringify(errorData)}`
        };
      }
      const fileInfo = await fileInfoResponse.json();
      if (!fileInfo.ok || !fileInfo.result.file_path) {
        logger?.error("\u274C [telegramDownloadPhoto] Invalid file info response:", fileInfo);
        return {
          success: false,
          error: "File path tidak ditemukan dalam response Telegram"
        };
      }
      const filePath = fileInfo.result.file_path;
      const fileSize = fileInfo.result.file_size || 0;
      const fileExtension = filePath.split(".").pop() || "jpg";
      logger?.info("\u{1F4DD} [telegramDownloadPhoto] Downloading file from Telegram...", {
        filePath,
        fileSize,
        fileExtension
      });
      const downloadUrl = `https://api.telegram.org/file/bot${token}/${filePath}`;
      const downloadResponse = await fetch(downloadUrl);
      if (!downloadResponse.ok) {
        logger?.error("\u274C [telegramDownloadPhoto] Failed to download file");
        return {
          success: false,
          error: `Gagal mendownload file: ${downloadResponse.statusText}`
        };
      }
      const buffer = await downloadResponse.arrayBuffer();
      const bufferData = Buffer.from(buffer);
      logger?.info("\u{1F4CA} [telegramDownloadPhoto] Downloaded buffer info:", {
        byteLength: buffer.byteLength,
        bufferLength: bufferData.length,
        expectedSize: fileSize
      });
      if (bufferData.length === 0) {
        logger?.error("\u274C [telegramDownloadPhoto] Downloaded buffer is empty!");
        return {
          success: false,
          error: "File yang di-download kosong (0 bytes)"
        };
      }
      if (fileSize > 0 && Math.abs(bufferData.length - fileSize) > 1e3) {
        logger?.warn("\u26A0\uFE0F [telegramDownloadPhoto] Size mismatch:", {
          expected: fileSize,
          actual: bufferData.length,
          difference: Math.abs(bufferData.length - fileSize)
        });
      }
      const baseFileName = context.fileName || `photo_${Date.now()}`;
      const fileName = baseFileName.includes(".") ? baseFileName : `${baseFileName}.${fileExtension}`;
      const tmpDir = "/tmp/telegram_photos";
      if (!fs.existsSync(tmpDir)) {
        fs.mkdirSync(tmpDir, { recursive: true });
      }
      const localFilePath = path.join(tmpDir, fileName);
      fs.writeFileSync(localFilePath, bufferData);
      const stats = fs.statSync(localFilePath);
      logger?.info("\u2705 [telegramDownloadPhoto] Photo downloaded successfully:", {
        localFilePath,
        fileSize: stats.size,
        expectedSize: fileSize,
        bufferSize: bufferData.length,
        fileExtension
      });
      if (stats.size === 0) {
        logger?.error("\u274C [telegramDownloadPhoto] Written file is empty!");
        return {
          success: false,
          error: "File tersimpan dengan ukuran 0 bytes"
        };
      }
      if (stats.size < 1024) {
        logger?.warn("\u26A0\uFE0F [telegramDownloadPhoto] File size is very small (< 1KB), might be corrupt:", stats.size);
      }
      return {
        success: true,
        filePath: localFilePath,
        fileSize: stats.size
      };
    } catch (error) {
      logger?.error("\u274C [telegramDownloadPhoto] Error:", error);
      return {
        success: false,
        error: `Error: ${error.message}`
      };
    }
  }
});

const ffmpegConvertVideo = createTool({
  id: "ffmpeg-convert-video",
  description: "Convert video to Facebook-compatible format using FFmpeg (H.264 video codec, AAC audio codec)",
  inputSchema: z.object({
    videoPath: z.string().describe("Local file path of the original video to convert")
  }),
  outputSchema: z.object({
    success: z.boolean(),
    convertedVideoPath: z.string().optional(),
    originalSize: z.number().optional(),
    convertedSize: z.number().optional(),
    error: z.string().optional()
  }),
  execute: async ({ context, mastra }) => {
    const logger = mastra?.getLogger();
    logger?.info("\u{1F527} [ffmpegConvertVideo] Starting execution with params:", context);
    try {
      if (!fs.existsSync(context.videoPath)) {
        logger?.error("\u274C [ffmpegConvertVideo] Input file not found:", context.videoPath);
        return {
          success: false,
          error: `File input tidak ditemukan: ${context.videoPath}`
        };
      }
      const originalStats = fs.statSync(context.videoPath);
      const originalSize = originalStats.size;
      const originalSizeMB = (originalSize / 1024 / 1024).toFixed(2);
      logger?.info("\u{1F4CA} [ffmpegConvertVideo] Original file info:", {
        path: context.videoPath,
        size: originalSize,
        sizeMB: originalSizeMB + " MB"
      });
      const tmpDir = "/tmp/telegram_videos";
      if (!fs.existsSync(tmpDir)) {
        fs.mkdirSync(tmpDir, { recursive: true });
      }
      const inputFileName = path.basename(context.videoPath, path.extname(context.videoPath));
      const outputFileName = `${inputFileName}_converted.mp4`;
      const outputPath = path.join(tmpDir, outputFileName);
      logger?.info("\u{1F4DD} [ffmpegConvertVideo] Converting video to Facebook-compatible format...");
      logger?.info("\u{1F3AC} [ffmpegConvertVideo] Output path:", outputPath);
      const ffmpegCommand = `ffmpeg -i "${context.videoPath}" -c:v libx264 -profile:v baseline -level 3.0 -pix_fmt yuv420p -preset veryfast -crf 32 -vf scale=-2:480 -r 24 -maxrate 800k -bufsize 1600k -c:a aac -b:a 64k -ar 44100 -movflags +faststart -y "${outputPath}"`;
      logger?.info("\u{1F3A5} [ffmpegConvertVideo] Executing FFmpeg command...");
      logger?.debug("\u{1F4DD} [ffmpegConvertVideo] Command:", ffmpegCommand);
      try {
        const output = execSync(ffmpegCommand, {
          encoding: "utf8",
          stdio: "pipe",
          // Capture output but don't show in console
          maxBuffer: 10 * 1024 * 1024
          // 10MB buffer for large outputs
        });
        logger?.debug("\u{1F4DD} [ffmpegConvertVideo] FFmpeg output:", output);
      } catch (execError) {
        if (!fs.existsSync(outputPath)) {
          logger?.error("\u274C [ffmpegConvertVideo] FFmpeg conversion failed:", execError.message);
          logger?.error("\u274C [ffmpegConvertVideo] FFmpeg stderr:", execError.stderr?.toString() || "");
          return {
            success: false,
            error: `Konversi video gagal: ${execError.message}`
          };
        }
        logger?.debug("\u{1F4DD} [ffmpegConvertVideo] FFmpeg stderr (normal):", execError.stderr?.toString() || "");
      }
      if (!fs.existsSync(outputPath)) {
        logger?.error("\u274C [ffmpegConvertVideo] Output file was not created");
        return {
          success: false,
          error: "File hasil konversi tidak dibuat"
        };
      }
      const convertedStats = fs.statSync(outputPath);
      const convertedSize = convertedStats.size;
      const convertedSizeMB = (convertedSize / 1024 / 1024).toFixed(2);
      if (convertedSize === 0) {
        logger?.error("\u274C [ffmpegConvertVideo] Converted file is empty");
        fs.unlinkSync(outputPath);
        return {
          success: false,
          error: "File hasil konversi kosong (0 bytes)"
        };
      }
      logger?.info("\u2705 [ffmpegConvertVideo] Video converted successfully:", {
        outputPath,
        originalSize: originalSizeMB + " MB",
        convertedSize: convertedSizeMB + " MB",
        compressionRatio: (convertedSize / originalSize * 100).toFixed(2) + "%"
      });
      return {
        success: true,
        convertedVideoPath: outputPath,
        originalSize,
        convertedSize
      };
    } catch (error) {
      logger?.error("\u274C [ffmpegConvertVideo] Error:", error);
      return {
        success: false,
        error: `Error: ${error.message}`
      };
    }
  }
});

async function getPageAccessToken(userAccessToken, pageId) {
  try {
    const response = await fetch(
      `https://graph.facebook.com/v19.0/me/accounts?access_token=${userAccessToken}`
    );
    if (!response.ok) {
      const error = await response.json();
      throw new Error(`Failed to get page token: ${error.error?.message || "Unknown error"}`);
    }
    const data = await response.json();
    if (!data.data || data.data.length === 0) {
      throw new Error("No pages found for this user access token");
    }
    if (pageId) {
      const page = data.data.find((p) => p.id === pageId);
      if (!page) {
        throw new Error(`Page with ID ${pageId} not found in user's managed pages`);
      }
      return {
        pageAccessToken: page.access_token,
        pageId: page.id,
        pageName: page.name
      };
    }
    const firstPage = data.data[0];
    return {
      pageAccessToken: firstPage.access_token,
      pageId: firstPage.id,
      pageName: firstPage.name
    };
  } catch (error) {
    throw new Error(`Error getting page access token: ${error.message}`);
  }
}
async function getFacebookCredentials(logger) {
  const pageAccessToken = process.env.FB_PAGE_ACCESS_TOKEN;
  const userAccessToken = process.env.FB_USER_ACCESS_TOKEN;
  const pageId = process.env.FB_PAGE_ID;
  if (userAccessToken) {
    logger?.info("\u{1F511} [Facebook] Using user access token to get page token");
    try {
      const result = await getPageAccessToken(userAccessToken, pageId);
      logger?.info("\u2705 [Facebook] Successfully obtained page access token", {
        pageId: result.pageId,
        pageName: result.pageName
      });
      return {
        pageAccessToken: result.pageAccessToken,
        pageId: result.pageId
      };
    } catch (error) {
      logger?.error("\u274C [Facebook] Failed to exchange user token for page token:", error.message);
      logger?.warn("\u26A0\uFE0F [Facebook] Falling back to FB_PAGE_ACCESS_TOKEN");
    }
  }
  if (!pageAccessToken || !pageId) {
    throw new Error(
      "Missing Facebook credentials. Please set either:\n1. FB_USER_ACCESS_TOKEN (recommended) - will auto-exchange for page token\n2. FB_PAGE_ACCESS_TOKEN and FB_PAGE_ID - direct page token"
    );
  }
  logger?.info("\u{1F511} [Facebook] Using direct page access token");
  return {
    pageAccessToken,
    pageId
  };
}
const CONTENT_TYPE_MAP = {
  "mp4": "video/mp4",
  "mov": "video/quicktime",
  "avi": "video/x-msvideo",
  "wmv": "video/x-ms-wmv",
  "flv": "video/x-flv",
  "mkv": "video/x-matroska",
  "webm": "video/webm",
  "m4v": "video/x-m4v",
  "3gp": "video/3gpp",
  "mpeg": "video/mpeg",
  "mpg": "video/mpeg"
};
function getVideoMetadata(filePath) {
  const filename = filePath.split("/").pop() || "video.mp4";
  const parts = filename.split(".");
  const hasExtension = parts.length > 1 && parts[parts.length - 1].length > 0;
  const extension = hasExtension ? parts[parts.length - 1].toLowerCase() : "mp4";
  const contentType = CONTENT_TYPE_MAP[extension] || "video/mp4";
  const finalFilename = hasExtension ? filename : `${filename}.${extension}`;
  return {
    extension,
    contentType,
    filename: finalFilename
  };
}
function validateVideoFile(filePath, logger) {
  try {
    const fd = fs.openSync(filePath, "r");
    const buffer = Buffer.alloc(32);
    const bytesRead = fs.readSync(fd, buffer, 0, 32, 0);
    fs.closeSync(fd);
    if (bytesRead < 8) {
      logger?.warn("\u26A0\uFE0F [validateVideoFile] File too small to validate:", bytesRead, "bytes");
      return false;
    }
    const header = buffer.toString("ascii", 0, Math.min(bytesRead, 12));
    const hex = buffer.toString("hex", 0, Math.min(bytesRead, 8));
    if (buffer.toString("ascii", 4, 8) === "ftyp") {
      logger?.info("\u2705 [validateVideoFile] Valid MP4/MOV container detected");
      return true;
    }
    if (header.startsWith("RIFF") && buffer.toString("ascii", 8, 12) === "AVI ") {
      logger?.info("\u2705 [validateVideoFile] Valid AVI container detected");
      return true;
    }
    if (hex.startsWith("1a45dfa3")) {
      logger?.info("\u2705 [validateVideoFile] Valid WebM container detected");
      return true;
    }
    if (header.startsWith("FLV")) {
      logger?.info("\u2705 [validateVideoFile] Valid FLV container detected");
      return true;
    }
    if (hex.startsWith("000001ba") || hex.startsWith("000001b3")) {
      logger?.info("\u2705 [validateVideoFile] Valid MPEG container detected");
      return true;
    }
    logger?.warn("\u26A0\uFE0F [validateVideoFile] Unknown video format, header:", {
      ascii: header,
      hex
    });
    return true;
  } catch (error) {
    logger?.error("\u274C [validateVideoFile] Error validating file:", error.message);
    return false;
  }
}

function isTransientError(errorResult) {
  if (errorResult.error?.is_transient === true) {
    return true;
  }
  const errorCode = errorResult.error?.code;
  const errorSubcode = errorResult.error?.error_subcode;
  if (errorCode === 390 && errorSubcode === 1363030) {
    return true;
  }
  if (errorCode === 1) {
    return true;
  }
  if (errorCode === 2) {
    return true;
  }
  return false;
}
function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}
const facebookUploadVideo = createTool({
  id: "facebook-upload-video",
  description: "Upload video to Facebook Page using Graph API",
  inputSchema: z.object({
    videoPath: z.string().describe("Local file path of the video to upload"),
    title: z.string().describe("Title for the video"),
    description: z.string().describe("Description/caption for the video (can include hashtags)")
  }),
  outputSchema: z.object({
    success: z.boolean(),
    videoId: z.string().optional(),
    postId: z.string().optional(),
    videoUrl: z.string().optional(),
    error: z.string().optional(),
    errorType: z.string().optional(),
    errorDetails: z.any().optional()
  }),
  execute: async ({ context, mastra }) => {
    const logger = mastra?.getLogger();
    logger?.info("\u{1F527} [facebookUploadVideo] Starting execution with params:", {
      videoPath: context.videoPath,
      title: context.title,
      descriptionLength: context.description.length
    });
    let pageAccessToken;
    let pageId;
    try {
      const credentials = await getFacebookCredentials(logger);
      pageAccessToken = credentials.pageAccessToken;
      pageId = credentials.pageId;
    } catch (error) {
      logger?.error("\u274C [facebookUploadVideo] Failed to get Facebook credentials:", error.message);
      return {
        success: false,
        error: `Kredensial Facebook tidak valid: ${error.message}`,
        errorType: "UNKNOWN_ERROR"
        /* UNKNOWN */
      };
    }
    try {
      if (!fs.existsSync(context.videoPath)) {
        logger?.error("\u274C [facebookUploadVideo] File not found:", context.videoPath);
        return {
          success: false,
          error: `File tidak ditemukan: ${context.videoPath}`,
          errorType: "UNKNOWN_ERROR"
          /* UNKNOWN */
        };
      }
      const fileStats = fs.statSync(context.videoPath);
      logger?.info("\u{1F4CA} [facebookUploadVideo] File info:", {
        path: context.videoPath,
        size: fileStats.size,
        sizeKB: (fileStats.size / 1024).toFixed(2) + " KB",
        sizeMB: (fileStats.size / 1024 / 1024).toFixed(2) + " MB"
      });
      if (fileStats.size === 0) {
        logger?.error("\u274C [facebookUploadVideo] File is empty (0 bytes)");
        return {
          success: false,
          error: "File video kosong (0 bytes). Video gagal di-download dengan benar.",
          errorType: "UNKNOWN_ERROR"
          /* UNKNOWN */
        };
      }
      if (fileStats.size < 1024) {
        logger?.error("\u274C [facebookUploadVideo] File too small (likely corrupt):", fileStats.size);
        return {
          success: false,
          error: `File video terlalu kecil (${fileStats.size} bytes), kemungkinan corrupt atau tidak lengkap.`,
          errorType: "UNKNOWN_ERROR"
          /* UNKNOWN */
        };
      }
      logger?.info("\u{1F50D} [facebookUploadVideo] Validating video file...");
      const isValid = validateVideoFile(context.videoPath, logger);
      if (!isValid) {
        logger?.error("\u274C [facebookUploadVideo] Video file validation failed");
        return {
          success: false,
          error: "File video tidak valid. File mungkin corrupt atau bukan format video yang didukung.",
          errorType: "UNKNOWN_ERROR"
          /* UNKNOWN */
        };
      }
      const videoMetadata = getVideoMetadata(context.videoPath);
      logger?.info("\u{1F4CA} [facebookUploadVideo] Video metadata:", videoMetadata);
      logger?.info("\u{1F4DD} [facebookUploadVideo] Uploading video to Facebook Page...");
      logger?.info("\u{1F511} [facebookUploadVideo] Using credentials:", {
        pageId,
        tokenLength: pageAccessToken.length,
        tokenPrefix: pageAccessToken.substring(0, 20) + "..."
      });
      const MAX_RETRIES = 3;
      const BASE_DELAY = 2e3;
      const UPLOAD_TIMEOUT = 3e5;
      let lastError = null;
      let lastErrorType = "UNKNOWN_ERROR";
      for (let attempt = 1; attempt <= MAX_RETRIES; attempt++) {
        logger?.info(`\u{1F504} [facebookUploadVideo] Upload attempt ${attempt}/${MAX_RETRIES}`);
        const abortController = new AbortController();
        const timeoutId = setTimeout(() => {
          logger?.warn(`\u23F1\uFE0F [facebookUploadVideo] Upload timeout (${UPLOAD_TIMEOUT}ms) reached - aborting request`);
          abortController.abort();
        }, UPLOAD_TIMEOUT);
        try {
          logger?.info("\u{1F4E6} [facebookUploadVideo] Creating FormData with fresh stream");
          const formData = new FormData();
          const videoStream = fs.createReadStream(context.videoPath);
          formData.append("source", videoStream, {
            filename: videoMetadata.filename,
            contentType: videoMetadata.contentType
          });
          formData.append("title", context.title);
          formData.append("description", context.description);
          const uploadUrl = `https://graph-video.facebook.com/v19.0/${pageId}/videos?access_token=${encodeURIComponent(pageAccessToken)}`;
          logger?.info("\u{1F4E4} [facebookUploadVideo] Sending request to Facebook API with timeout", {
            timeout: UPLOAD_TIMEOUT,
            timeoutSeconds: UPLOAD_TIMEOUT / 1e3,
            attempt
          });
          const uploadResponse = await fetch(uploadUrl, {
            method: "POST",
            body: formData,
            headers: formData.getHeaders(),
            signal: abortController.signal
          });
          clearTimeout(timeoutId);
          const uploadResult = await uploadResponse.json();
          logger?.info("\u{1F4CA} [facebookUploadVideo] Facebook API response:", {
            ok: uploadResponse.ok,
            status: uploadResponse.status,
            hasError: !!uploadResult.error,
            result: uploadResult
          });
          if (!uploadResponse.ok || uploadResult.error) {
            const errorCode = uploadResult.error?.code || uploadResponse.status;
            const errorMessage = uploadResult.error?.message || "Unknown error";
            const errorType = uploadResult.error?.type || "Unknown";
            const errorSubcode = uploadResult.error?.error_subcode;
            const isTransient = uploadResult.error?.is_transient;
            logger?.error("\u274C [facebookUploadVideo] API Error detected:", {
              errorType: "API_ERROR",
              attempt,
              code: errorCode,
              subcode: errorSubcode,
              message: errorMessage,
              type: errorType,
              isTransient,
              fullError: uploadResult
            });
            lastError = uploadResult;
            lastErrorType = "API_ERROR";
            if (isTransientError(uploadResult)) {
              if (attempt < MAX_RETRIES) {
                const delay = BASE_DELAY * Math.pow(2, attempt - 1);
                logger?.warn(`\u26A0\uFE0F [facebookUploadVideo] Transient API error detected (timeout/koneksi lambat)`);
                logger?.warn(`\u{1F504} [facebookUploadVideo] Retry ${attempt + 1}/${MAX_RETRIES} akan dimulai dalam ${delay}ms...`);
                await sleep(delay);
                continue;
              } else {
                logger?.error("\u274C [facebookUploadVideo] Max retries reached for transient API error");
                return {
                  success: false,
                  error: `Upload gagal setelah ${MAX_RETRIES} kali percobaan. Koneksi ke Facebook timeout atau lambat. Silakan coba lagi nanti.`,
                  errorType: "API_ERROR",
                  errorDetails: uploadResult
                };
              }
            }
            let userMessage = errorMessage;
            if (errorCode === 390 && errorSubcode !== 1363030) {
              userMessage = "File video tidak valid atau corrupt. Pastikan video yang dikirim bisa diputar dan tidak rusak.";
            } else if (errorCode === 100) {
              userMessage = "Permission error: Token Facebook tidak memiliki izin untuk upload video.";
            } else if (errorCode === 200) {
              userMessage = "Permission error: Token memerlukan permission tambahan.";
            }
            return {
              success: false,
              error: `Upload gagal: ${userMessage}`,
              errorType: "API_ERROR",
              errorDetails: uploadResult
            };
          }
          const videoId = uploadResult.id;
          const postId = uploadResult.post_id || uploadResult.id;
          const videoUrl = `https://www.facebook.com/${pageId}/videos/${videoId}`;
          logger?.info("\u2705 [facebookUploadVideo] Video uploaded successfully:", {
            videoId,
            postId,
            videoUrl,
            attemptNumber: attempt
          });
          return {
            success: true,
            videoId,
            postId,
            videoUrl
          };
        } catch (fetchError) {
          clearTimeout(timeoutId);
          let detectedErrorType = "UNKNOWN_ERROR";
          let errorMessage = fetchError.message || "Unknown error";
          if (fetchError.name === "AbortError") {
            detectedErrorType = "TIMEOUT_ERROR";
            errorMessage = `Upload timeout setelah ${UPLOAD_TIMEOUT / 1e3} detik`;
            logger?.error("\u23F1\uFE0F [facebookUploadVideo] Timeout error detected:", {
              errorType: "TIMEOUT_ERROR",
              attempt,
              timeout: UPLOAD_TIMEOUT,
              timeoutSeconds: UPLOAD_TIMEOUT / 1e3,
              message: errorMessage
            });
          } else if (fetchError.code === "ECONNREFUSED" || fetchError.code === "ENOTFOUND" || fetchError.code === "ECONNRESET" || fetchError.code === "ETIMEDOUT" || fetchError.code === "EAI_AGAIN" || fetchError.type === "system") {
            detectedErrorType = "NETWORK_ERROR";
            errorMessage = `Network error: ${fetchError.code || fetchError.message}`;
            logger?.error("\u{1F310} [facebookUploadVideo] Network error detected:", {
              errorType: "NETWORK_ERROR",
              attempt,
              code: fetchError.code,
              message: fetchError.message,
              errno: fetchError.errno,
              syscall: fetchError.syscall
            });
          } else {
            logger?.error("\u2753 [facebookUploadVideo] Unknown fetch error:", {
              errorType: "UNKNOWN_ERROR",
              attempt,
              name: fetchError.name,
              message: fetchError.message,
              code: fetchError.code,
              stack: fetchError.stack
            });
          }
          lastError = fetchError;
          lastErrorType = detectedErrorType;
          if ((detectedErrorType === "NETWORK_ERROR" || detectedErrorType === "TIMEOUT_ERROR") && attempt < MAX_RETRIES) {
            const delay = BASE_DELAY * Math.pow(2, attempt - 1);
            logger?.warn(`\u26A0\uFE0F [facebookUploadVideo] Transient ${detectedErrorType} detected - will retry`);
            logger?.warn(`\u{1F504} [facebookUploadVideo] Retry ${attempt + 1}/${MAX_RETRIES} akan dimulai dalam ${delay}ms...`);
            await sleep(delay);
            continue;
          }
          if (attempt >= MAX_RETRIES) {
            logger?.error("\u274C [facebookUploadVideo] Max retries reached for network/timeout error");
            return {
              success: false,
              error: `Upload gagal setelah ${MAX_RETRIES} kali percobaan. ${detectedErrorType === "TIMEOUT_ERROR" ? "Upload timeout - koneksi terlalu lambat." : "Network error - periksa koneksi internet."} Silakan coba lagi.`,
              errorType: detectedErrorType,
              errorDetails: {
                message: fetchError.message,
                code: fetchError.code,
                name: fetchError.name
              }
            };
          }
          return {
            success: false,
            error: `Upload error: ${errorMessage}`,
            errorType: detectedErrorType,
            errorDetails: {
              message: fetchError.message,
              name: fetchError.name,
              code: fetchError.code
            }
          };
        }
      }
      logger?.error("\u274C [facebookUploadVideo] All retry attempts exhausted");
      return {
        success: false,
        error: `Upload gagal setelah ${MAX_RETRIES} kali percobaan. ${lastErrorType === "TIMEOUT_ERROR" ? "Upload timeout." : lastErrorType === "NETWORK_ERROR" ? "Network error." : "API error."} Silakan coba lagi nanti.`,
        errorType: lastErrorType,
        errorDetails: lastError
      };
    } catch (error) {
      logger?.error("\u274C [facebookUploadVideo] Unexpected error:", error);
      return {
        success: false,
        error: `Error: ${error.message}`,
        errorType: "UNKNOWN_ERROR",
        errorDetails: {
          message: error.message,
          stack: error.stack
        }
      };
    }
  }
});

const facebookUploadVideoResumable = createTool({
  id: "facebook-upload-video-resumable",
  description: "Upload video to Facebook Page using Resumable Upload API (more reliable for larger files)",
  inputSchema: z.object({
    videoPath: z.string().describe("Local file path of the video to upload"),
    title: z.string().describe("Title for the video"),
    description: z.string().describe("Description/caption for the video (can include hashtags)")
  }),
  outputSchema: z.object({
    success: z.boolean(),
    videoId: z.string().optional(),
    postId: z.string().optional(),
    videoUrl: z.string().optional(),
    error: z.string().optional()
  }),
  execute: async ({ context, mastra }) => {
    const logger = mastra?.getLogger();
    logger?.info("\u{1F527} [facebookUploadVideoResumable] Starting resumable upload with params:", {
      videoPath: context.videoPath,
      title: context.title,
      descriptionLength: context.description.length
    });
    let pageAccessToken;
    let pageId;
    try {
      const credentials = await getFacebookCredentials(logger);
      pageAccessToken = credentials.pageAccessToken;
      pageId = credentials.pageId;
    } catch (error) {
      logger?.error("\u274C [facebookUploadVideoResumable] Failed to get Facebook credentials:", error.message);
      return {
        success: false,
        error: `Kredensial Facebook tidak valid: ${error.message}`
      };
    }
    try {
      if (!fs.existsSync(context.videoPath)) {
        logger?.error("\u274C [facebookUploadVideoResumable] File not found:", context.videoPath);
        return {
          success: false,
          error: `File tidak ditemukan: ${context.videoPath}`
        };
      }
      const fileStats = fs.statSync(context.videoPath);
      const fileSize = fileStats.size;
      logger?.info("\u{1F4CA} [facebookUploadVideoResumable] File info:", {
        path: context.videoPath,
        size: fileSize,
        sizeKB: (fileSize / 1024).toFixed(2) + " KB",
        sizeMB: (fileSize / 1024 / 1024).toFixed(2) + " MB"
      });
      if (fileSize === 0) {
        logger?.error("\u274C [facebookUploadVideoResumable] File is empty");
        return {
          success: false,
          error: "File video kosong (0 bytes)"
        };
      }
      logger?.info("\u{1F50D} [facebookUploadVideoResumable] Validating video file...");
      const isValid = validateVideoFile(context.videoPath, logger);
      if (!isValid) {
        logger?.error("\u274C [facebookUploadVideoResumable] Video file validation failed");
        return {
          success: false,
          error: "File video tidak valid. File mungkin corrupt atau bukan format video yang didukung."
        };
      }
      const videoMetadata = getVideoMetadata(context.videoPath);
      logger?.info("\u{1F4CA} [facebookUploadVideoResumable] Video metadata:", videoMetadata);
      logger?.info("\u{1F4DD} [facebookUploadVideoResumable] Step 1: Initializing upload session...");
      const initUrl = `https://graph-video.facebook.com/v19.0/${pageId}/videos`;
      const initParams = new URLSearchParams({
        access_token: pageAccessToken,
        upload_phase: "start",
        file_size: fileSize.toString()
      });
      const initResponse = await fetch(`${initUrl}?${initParams}`, {
        method: "POST"
      });
      const initResult = await initResponse.json();
      if (!initResponse.ok || initResult.error) {
        logger?.error("\u274C [facebookUploadVideoResumable] Failed to initialize upload:", initResult);
        return {
          success: false,
          error: `Gagal inisialisasi upload: ${initResult.error?.message || "Unknown error"}`
        };
      }
      const uploadSessionId = initResult.upload_session_id;
      const videoId = initResult.video_id;
      const initialStartOffset = parseInt(initResult.start_offset || "0");
      const CUSTOM_CHUNK_SIZE = 131072;
      const initialEndOffset = Math.min(initialStartOffset + CUSTOM_CHUNK_SIZE, fileSize);
      logger?.info("\u2705 [facebookUploadVideoResumable] Upload session initialized:", {
        uploadSessionId,
        videoId,
        initialStartOffset,
        initialEndOffset,
        initialChunkSize: initialEndOffset - initialStartOffset
      });
      logger?.info("\u{1F4E4} [facebookUploadVideoResumable] Step 2: Uploading video file in chunks...");
      const fd = fs.openSync(context.videoPath, "r");
      const tmpChunkDir = "/tmp/fb_chunks";
      if (!fs.existsSync(tmpChunkDir)) {
        fs.mkdirSync(tmpChunkDir, { recursive: true });
      }
      try {
        let currentStartOffset = initialStartOffset;
        let currentEndOffset = Math.min(initialEndOffset, fileSize);
        let chunkNumber = 0;
        let previousOffset = -1;
        while (currentStartOffset < fileSize) {
          chunkNumber++;
          if (currentStartOffset === previousOffset) {
            logger?.error("\u274C [facebookUploadVideoResumable] Upload stalled - offset not advancing");
            throw new Error("Upload stalled: offset not advancing. Please try again.");
          }
          previousOffset = currentStartOffset;
          const chunkSize = currentEndOffset - currentStartOffset;
          if (chunkSize <= 0) {
            logger?.error("\u274C [facebookUploadVideoResumable] Invalid chunk size:", chunkSize);
            throw new Error(`Invalid chunk size: ${chunkSize}. Facebook returned inconsistent offsets.`);
          }
          if (chunkSize > fileSize - currentStartOffset) {
            logger?.error("\u274C [facebookUploadVideoResumable] Chunk size exceeds remaining file size");
            throw new Error(`Chunk size ${chunkSize} exceeds remaining ${fileSize - currentStartOffset} bytes.`);
          }
          logger?.info(`\u{1F4E6} [facebookUploadVideoResumable] Uploading chunk ${chunkNumber}...`, {
            startOffset: currentStartOffset,
            endOffset: currentEndOffset,
            chunkSize,
            totalSize: fileSize,
            progress: `${(currentStartOffset / fileSize * 100).toFixed(1)}%`
          });
          const buffer = Buffer.alloc(chunkSize);
          fs.readSync(fd, buffer, 0, chunkSize, currentStartOffset);
          const chunkFilePath = `${tmpChunkDir}/chunk_${Date.now()}_${chunkNumber}.${videoMetadata.extension}`;
          fs.writeFileSync(chunkFilePath, buffer);
          logger?.info(`\u{1F4BE} [facebookUploadVideoResumable] Chunk written to temp file:`, {
            path: chunkFilePath,
            size: fs.statSync(chunkFilePath).size
          });
          try {
            const uploadUrl = `https://graph-video.facebook.com/v19.0/${pageId}/videos?access_token=${encodeURIComponent(pageAccessToken)}`;
            const MAX_CHUNK_RETRIES = 5;
            let chunkUploadSuccess = false;
            let nextStartOffset = currentStartOffset;
            let nextEndOffset = currentEndOffset;
            for (let retryAttempt = 1; retryAttempt <= MAX_CHUNK_RETRIES; retryAttempt++) {
              try {
                const form = new FormData();
                form.append("upload_phase", "transfer");
                form.append("start_offset", currentStartOffset.toString());
                form.append("upload_session_id", uploadSessionId);
                form.append("video_file_chunk", fs.createReadStream(chunkFilePath), {
                  filename: `chunk.${videoMetadata.extension}`,
                  contentType: videoMetadata.contentType
                });
                logger?.info(`\u{1F53C} [facebookUploadVideoResumable] Sending chunk ${chunkNumber} (attempt ${retryAttempt}/${MAX_CHUNK_RETRIES})...`, {
                  url: uploadUrl.split("?")[0],
                  contentType: videoMetadata.contentType,
                  chunkSize
                });
                if (chunkNumber > 1 || retryAttempt > 1) {
                  const delayMs = retryAttempt > 1 ? 5e3 * retryAttempt : 3e3;
                  logger?.info(`\u23F1\uFE0F [facebookUploadVideoResumable] Waiting ${delayMs}ms before uploading...`);
                  await new Promise((resolve) => setTimeout(resolve, delayMs));
                }
                const uploadResponse = await axios.post(uploadUrl, form, {
                  headers: form.getHeaders(),
                  maxContentLength: Infinity,
                  maxBodyLength: Infinity,
                  validateStatus: () => true
                  // Don't throw on any status code
                });
                const uploadResult = uploadResponse.data;
                logger?.info(`\u{1F4E9} [facebookUploadVideoResumable] Facebook response for chunk ${chunkNumber} (attempt ${retryAttempt}):`, {
                  status: uploadResponse.status,
                  ok: uploadResponse.status >= 200 && uploadResponse.status < 300,
                  result: uploadResult
                });
                if (uploadResponse.status < 200 || uploadResponse.status >= 300 || uploadResult.error) {
                  const isTransient = uploadResult.error?.error_subcode === 1363030 || uploadResult.error?.is_transient === true;
                  logger?.error(`\u274C [facebookUploadVideoResumable] Chunk ${chunkNumber} upload failed (attempt ${retryAttempt}):`, {
                    status: uploadResponse.status,
                    statusText: uploadResponse.statusText,
                    error: uploadResult.error,
                    errorMessage: uploadResult.error?.message,
                    errorCode: uploadResult.error?.code,
                    errorSubcode: uploadResult.error?.error_subcode,
                    isTransient,
                    fullResponse: uploadResult
                  });
                  if (isTransient && retryAttempt < MAX_CHUNK_RETRIES) {
                    logger?.warn(`\u26A0\uFE0F [facebookUploadVideoResumable] Transient error detected, will retry chunk ${chunkNumber}...`);
                    continue;
                  } else {
                    throw new Error(`Upload gagal pada chunk ${chunkNumber} setelah ${retryAttempt} percobaan: ${uploadResult.error?.message || "Unknown error"}`);
                  }
                }
                nextStartOffset = parseInt(uploadResult.start_offset || "0");
                const facebookSuggestedEndOffset = parseInt(uploadResult.end_offset || fileSize.toString());
                nextEndOffset = Math.min(facebookSuggestedEndOffset, nextStartOffset + CUSTOM_CHUNK_SIZE, fileSize);
                logger?.info(`\u2705 [facebookUploadVideoResumable] Chunk ${chunkNumber} uploaded successfully (attempt ${retryAttempt})`, {
                  nextStartOffset,
                  nextEndOffset,
                  facebookSuggested: facebookSuggestedEndOffset,
                  customChunkSize: CUSTOM_CHUNK_SIZE,
                  remaining: fileSize - nextStartOffset
                });
                chunkUploadSuccess = true;
                break;
              } catch (fetchError) {
                logger?.error(`\u274C [facebookUploadVideoResumable] Network error uploading chunk ${chunkNumber} (attempt ${retryAttempt}):`, fetchError.message);
                if (retryAttempt >= MAX_CHUNK_RETRIES) {
                  throw new Error(`Upload gagal pada chunk ${chunkNumber} setelah ${retryAttempt} percobaan: ${fetchError.message}`);
                }
                logger?.warn(`\u26A0\uFE0F [facebookUploadVideoResumable] Network error, will retry chunk ${chunkNumber}...`);
                continue;
              }
            }
            if (!chunkUploadSuccess) {
              throw new Error(`Upload gagal pada chunk ${chunkNumber} setelah ${MAX_CHUNK_RETRIES} percobaan`);
            }
            currentStartOffset = nextStartOffset;
            currentEndOffset = Math.min(nextEndOffset, fileSize);
          } finally {
            try {
              fs.unlinkSync(chunkFilePath);
              logger?.info(`\u{1F5D1}\uFE0F [facebookUploadVideoResumable] Temp chunk file deleted: ${chunkFilePath}`);
            } catch (cleanupError) {
              logger?.warn(`\u26A0\uFE0F [facebookUploadVideoResumable] Failed to delete temp chunk: ${cleanupError}`);
            }
          }
          if (currentStartOffset >= currentEndOffset || currentStartOffset >= fileSize) {
            break;
          }
        }
        logger?.info("\u2705 [facebookUploadVideoResumable] All chunks uploaded successfully");
      } finally {
        fs.closeSync(fd);
        logger?.info("\u{1F5D1}\uFE0F [facebookUploadVideoResumable] File descriptor closed");
        try {
          if (fs.existsSync(tmpChunkDir)) {
            const files = fs.readdirSync(tmpChunkDir);
            for (const file of files) {
              fs.unlinkSync(`${tmpChunkDir}/${file}`);
            }
            fs.rmdirSync(tmpChunkDir);
            logger?.info("\u{1F5D1}\uFE0F [facebookUploadVideoResumable] Temp chunk directory cleaned");
          }
        } catch (cleanupError) {
          logger?.warn("\u26A0\uFE0F [facebookUploadVideoResumable] Failed to clean temp directory:", cleanupError);
        }
      }
      logger?.info("\u{1F4DD} [facebookUploadVideoResumable] Step 3: Finalizing upload...");
      const finalizeUrl = `https://graph-video.facebook.com/v19.0/${pageId}/videos`;
      const finalizeParams = new URLSearchParams({
        access_token: pageAccessToken,
        upload_phase: "finish",
        upload_session_id: uploadSessionId,
        title: context.title,
        description: context.description
      });
      const finalizeResponse = await fetch(`${finalizeUrl}?${finalizeParams}`, {
        method: "POST"
      });
      const finalizeResult = await finalizeResponse.json();
      if (!finalizeResponse.ok || finalizeResult.error) {
        logger?.error("\u274C [facebookUploadVideoResumable] Failed to finalize:", finalizeResult);
        return {
          success: false,
          error: `Gagal finalisasi upload: ${finalizeResult.error?.message || "Unknown error"}`
        };
      }
      logger?.info("\u2705 [facebookUploadVideoResumable] Upload finalized successfully");
      const success = finalizeResult.success === true;
      const videoUrl = `https://www.facebook.com/${pageId}/videos/${videoId}`;
      logger?.info("\u{1F389} [facebookUploadVideoResumable] Video uploaded successfully:", {
        videoId,
        videoUrl,
        success
      });
      return {
        success: true,
        videoId,
        postId: videoId,
        videoUrl
      };
    } catch (error) {
      logger?.error("\u274C [facebookUploadVideoResumable] Error:", error);
      return {
        success: false,
        error: `Error: ${error.message}`
      };
    }
  }
});

const FILE_SIZE_THRESHOLD = parseInt(process.env.FB_UPLOAD_SIZE_THRESHOLD || "20971520");
const facebookUploadVideoSmart = createTool({
  id: "facebook-upload-video-smart",
  description: "Intelligently upload video to Facebook Page by choosing the best method based on file size (simple upload for small files, resumable for large files)",
  inputSchema: z.object({
    videoPath: z.string().describe("Local file path of the video to upload"),
    title: z.string().describe("Title for the video"),
    description: z.string().describe("Description/caption for the video (can include hashtags)")
  }),
  outputSchema: z.object({
    success: z.boolean(),
    videoId: z.string().optional(),
    postId: z.string().optional(),
    videoUrl: z.string().optional(),
    error: z.string().optional(),
    uploadMethod: z.enum(["simple", "resumable"]).optional()
  }),
  execute: async ({ context, mastra }) => {
    const logger = mastra?.getLogger();
    logger?.info("\u{1F527} [facebookUploadVideoSmart] Starting smart upload with params:", {
      videoPath: context.videoPath,
      title: context.title,
      descriptionLength: context.description.length
    });
    try {
      if (!fs.existsSync(context.videoPath)) {
        logger?.error("\u274C [facebookUploadVideoSmart] File not found:", context.videoPath);
        return {
          success: false,
          error: `File tidak ditemukan: ${context.videoPath}`
        };
      }
      const fileStats = fs.statSync(context.videoPath);
      const fileSize = fileStats.size;
      const fileSizeMB = (fileSize / 1024 / 1024).toFixed(2);
      const thresholdMB = (FILE_SIZE_THRESHOLD / 1024 / 1024).toFixed(2);
      logger?.info("\u{1F4CA} [facebookUploadVideoSmart] File analysis:", {
        path: context.videoPath,
        size: fileSize,
        sizeKB: (fileSize / 1024).toFixed(2) + " KB",
        sizeMB: fileSizeMB + " MB",
        threshold: thresholdMB + " MB"
      });
      if (fileSize === 0) {
        logger?.error("\u274C [facebookUploadVideoSmart] File is empty");
        return {
          success: false,
          error: "File video kosong (0 bytes)"
        };
      }
      const useSimpleUpload = fileSize < FILE_SIZE_THRESHOLD;
      const uploadMethod = useSimpleUpload ? "simple" : "resumable";
      logger?.info(`\u{1F3AF} [facebookUploadVideoSmart] Upload decision: ${uploadMethod.toUpperCase()}`, {
        fileSize: fileSizeMB + " MB",
        threshold: thresholdMB + " MB",
        reason: useSimpleUpload ? "File kecil (<" + thresholdMB + "MB), menggunakan simple upload" : "File besar (>=" + thresholdMB + "MB), menggunakan resumable upload"
      });
      let uploadResult;
      let actualUploadMethod = uploadMethod;
      if (useSimpleUpload) {
        logger?.info("\u{1F4E4} [facebookUploadVideoSmart] Using SIMPLE upload method...");
        uploadResult = await facebookUploadVideo.execute({
          context: {
            videoPath: context.videoPath,
            title: context.title,
            description: context.description
          },
          mastra,
          runtimeContext: {}
        });
        const shouldRetryWithResumable = !uploadResult.success && (uploadResult.error?.includes("1363030") || uploadResult.error?.includes("timeout") || uploadResult.error?.includes("Upload gagal setelah") || uploadResult.errorType === "TIMEOUT_ERROR");
        if (shouldRetryWithResumable) {
          logger?.warn("\u26A0\uFE0F [facebookUploadVideoSmart] Simple upload failed (timeout/transient error), retrying with resumable upload...");
          logger?.warn(`\u26A0\uFE0F [facebookUploadVideoSmart] Error: ${uploadResult.error}`);
          if (!fs__default.existsSync(context.videoPath)) {
            logger?.error("\u274C [facebookUploadVideoSmart] Video file was deleted by simple upload, cannot retry");
            return uploadResult;
          }
          uploadResult = await facebookUploadVideoResumable.execute({
            context: {
              videoPath: context.videoPath,
              title: context.title,
              description: context.description
            },
            mastra,
            runtimeContext: {}
          });
          actualUploadMethod = "resumable";
          if (uploadResult.success) {
            logger?.info("\u2705 [facebookUploadVideoSmart] Resumable upload (retry) succeeded!");
          } else {
            logger?.error("\u274C [facebookUploadVideoSmart] Resumable upload (retry) also failed");
          }
        }
      } else {
        logger?.info("\u{1F4E4} [facebookUploadVideoSmart] Using RESUMABLE upload method...");
        uploadResult = await facebookUploadVideoResumable.execute({
          context: {
            videoPath: context.videoPath,
            title: context.title,
            description: context.description
          },
          mastra,
          runtimeContext: {}
        });
      }
      try {
        if (fs.existsSync(context.videoPath)) {
          fs.unlinkSync(context.videoPath);
          logger?.info("\u{1F5D1}\uFE0F [facebookUploadVideoSmart] Temporary video file cleaned up:", context.videoPath);
        }
      } catch (cleanupError) {
        logger?.warn("\u26A0\uFE0F [facebookUploadVideoSmart] Failed to clean up temporary file:", cleanupError.message);
      }
      if (uploadResult.success) {
        logger?.info("\u2705 [facebookUploadVideoSmart] Upload successful!", {
          method: actualUploadMethod,
          videoId: uploadResult.videoId,
          videoUrl: uploadResult.videoUrl
        });
        return {
          success: true,
          videoId: uploadResult.videoId,
          postId: uploadResult.postId,
          videoUrl: uploadResult.videoUrl,
          uploadMethod: actualUploadMethod
        };
      } else {
        logger?.error("\u274C [facebookUploadVideoSmart] Upload failed:", {
          error: uploadResult.error,
          method: actualUploadMethod
        });
        return {
          success: false,
          error: uploadResult.error,
          uploadMethod: actualUploadMethod
        };
      }
    } catch (error) {
      logger?.error("\u274C [facebookUploadVideoSmart] Error:", error);
      return {
        success: false,
        error: `Error: ${error.message}`
      };
    }
  }
});

const PHOTO_CONTENT_TYPE_MAP = {
  "jpg": "image/jpeg",
  "jpeg": "image/jpeg",
  "png": "image/png",
  "gif": "image/gif",
  "webp": "image/webp",
  "bmp": "image/bmp"
};
function getPhotoMetadata(filePath) {
  const filename = filePath.split("/").pop() || "photo.jpg";
  const parts = filename.split(".");
  const hasExtension = parts.length > 1 && parts[parts.length - 1].length > 0;
  const extension = hasExtension ? parts[parts.length - 1].toLowerCase() : "jpg";
  const contentType = PHOTO_CONTENT_TYPE_MAP[extension] || "image/jpeg";
  const finalFilename = hasExtension ? filename : `${filename}.${extension}`;
  return {
    extension,
    contentType,
    filename: finalFilename
  };
}
function validatePhotoFile(filePath, logger) {
  try {
    const fd = fs.openSync(filePath, "r");
    const buffer = Buffer.alloc(12);
    const bytesRead = fs.readSync(fd, buffer, 0, 12, 0);
    fs.closeSync(fd);
    if (bytesRead < 4) {
      logger?.warn("\u26A0\uFE0F [validatePhotoFile] File too small to validate:", bytesRead, "bytes");
      return false;
    }
    const hex = buffer.toString("hex", 0, Math.min(bytesRead, 12));
    if (hex.startsWith("ffd8ff")) {
      logger?.info("\u2705 [validatePhotoFile] Valid JPEG detected");
      return true;
    }
    if (hex.startsWith("89504e47")) {
      logger?.info("\u2705 [validatePhotoFile] Valid PNG detected");
      return true;
    }
    if (hex.startsWith("474946")) {
      logger?.info("\u2705 [validatePhotoFile] Valid GIF detected");
      return true;
    }
    if (hex.startsWith("52494646") && buffer.toString("ascii", 8, 12) === "WEBP") {
      logger?.info("\u2705 [validatePhotoFile] Valid WebP detected");
      return true;
    }
    if (hex.startsWith("424d")) {
      logger?.info("\u2705 [validatePhotoFile] Valid BMP detected");
      return true;
    }
    logger?.warn("\u26A0\uFE0F [validatePhotoFile] Unknown image format, header:", {
      hex
    });
    return false;
  } catch (error) {
    logger?.error("\u274C [validatePhotoFile] Error validating file:", error.message);
    return false;
  }
}
const facebookUploadPhoto = createTool({
  id: "facebook-upload-photo",
  description: "Upload photo to Facebook Page using Graph API",
  inputSchema: z.object({
    photoPath: z.string().describe("Local file path of the photo to upload"),
    caption: z.string().describe("Caption for the photo (can include hashtags)")
  }),
  outputSchema: z.object({
    success: z.boolean(),
    postId: z.string().optional(),
    photoUrl: z.string().optional(),
    error: z.string().optional()
  }),
  execute: async ({ context, mastra }) => {
    const logger = mastra?.getLogger();
    logger?.info("\u{1F527} [facebookUploadPhoto] Starting execution with params:", {
      photoPath: context.photoPath,
      captionLength: context.caption.length
    });
    let pageAccessToken;
    let pageId;
    try {
      const credentials = await getFacebookCredentials(logger);
      pageAccessToken = credentials.pageAccessToken;
      pageId = credentials.pageId;
    } catch (error) {
      logger?.error("\u274C [facebookUploadPhoto] Failed to get Facebook credentials:", error.message);
      return {
        success: false,
        error: `Kredensial Facebook tidak valid: ${error.message}`
      };
    }
    try {
      if (!fs.existsSync(context.photoPath)) {
        logger?.error("\u274C [facebookUploadPhoto] File not found:", context.photoPath);
        return {
          success: false,
          error: `File tidak ditemukan: ${context.photoPath}`
        };
      }
      const fileStats = fs.statSync(context.photoPath);
      logger?.info("\u{1F4CA} [facebookUploadPhoto] File info:", {
        path: context.photoPath,
        size: fileStats.size,
        sizeKB: (fileStats.size / 1024).toFixed(2) + " KB",
        sizeMB: (fileStats.size / 1024 / 1024).toFixed(2) + " MB"
      });
      if (fileStats.size === 0) {
        logger?.error("\u274C [facebookUploadPhoto] File is empty (0 bytes)");
        return {
          success: false,
          error: "File foto kosong (0 bytes). Foto gagal di-download dengan benar."
        };
      }
      const MAX_PHOTO_SIZE = 8 * 1024 * 1024;
      if (fileStats.size > MAX_PHOTO_SIZE) {
        logger?.error("\u274C [facebookUploadPhoto] File too large:", {
          size: fileStats.size,
          maxSize: MAX_PHOTO_SIZE,
          sizeMB: (fileStats.size / 1024 / 1024).toFixed(2)
        });
        return {
          success: false,
          error: `File foto terlalu besar (${(fileStats.size / 1024 / 1024).toFixed(2)} MB). Maksimal 8 MB.`
        };
      }
      if (fileStats.size < 1024) {
        logger?.error("\u274C [facebookUploadPhoto] File too small (likely corrupt):", fileStats.size);
        return {
          success: false,
          error: `File foto terlalu kecil (${fileStats.size} bytes), kemungkinan corrupt atau tidak lengkap.`
        };
      }
      logger?.info("\u{1F50D} [facebookUploadPhoto] Validating photo file...");
      const isValid = validatePhotoFile(context.photoPath, logger);
      if (!isValid) {
        logger?.error("\u274C [facebookUploadPhoto] Photo file validation failed");
        return {
          success: false,
          error: "File foto tidak valid. File mungkin corrupt atau bukan format gambar yang didukung (JPEG/PNG/GIF)."
        };
      }
      const photoMetadata = getPhotoMetadata(context.photoPath);
      logger?.info("\u{1F4CA} [facebookUploadPhoto] Photo metadata:", photoMetadata);
      logger?.info("\u{1F4DD} [facebookUploadPhoto] Uploading photo to Facebook Page...");
      logger?.info("\u{1F511} [facebookUploadPhoto] Using credentials:", {
        pageId,
        tokenLength: pageAccessToken.length,
        tokenPrefix: pageAccessToken.substring(0, 20) + "..."
      });
      const formData = new FormData();
      formData.append("source", fs.createReadStream(context.photoPath), {
        filename: photoMetadata.filename,
        contentType: photoMetadata.contentType
      });
      formData.append("caption", context.caption);
      formData.append("published", "true");
      const uploadUrl = `https://graph.facebook.com/v21.0/${pageId}/photos?access_token=${encodeURIComponent(pageAccessToken)}`;
      logger?.info("\u{1F4E4} [facebookUploadPhoto] Sending request to Facebook API");
      const uploadResponse = await axios.post(uploadUrl, formData, {
        headers: formData.getHeaders(),
        maxContentLength: Infinity,
        maxBodyLength: Infinity
      });
      const uploadResult = uploadResponse.data;
      logger?.info("\u{1F4CA} [facebookUploadPhoto] Facebook API response:", {
        status: uploadResponse.status,
        hasError: !!uploadResult.error,
        result: uploadResult
      });
      if (uploadResult.error) {
        const errorCode = uploadResult.error?.code || uploadResponse.status;
        const errorMessage = uploadResult.error?.message || "Unknown error";
        const errorType = uploadResult.error?.type || "Unknown";
        const errorSubcode = uploadResult.error?.error_subcode;
        logger?.error("\u274C [facebookUploadPhoto] Upload failed:", {
          code: errorCode,
          subcode: errorSubcode,
          message: errorMessage,
          type: errorType,
          fullError: uploadResult
        });
        let userMessage = errorMessage;
        if (errorCode === 324) {
          userMessage = "File foto tidak valid atau corrupt. Pastikan foto yang dikirim bisa dibuka dan tidak rusak.";
        } else if (errorCode === 100) {
          userMessage = "Permission error: Token Facebook tidak memiliki izin untuk upload foto.";
        } else if (errorCode === 200) {
          userMessage = "Permission error: Token memerlukan permission tambahan.";
        } else if (errorCode === 190) {
          userMessage = "Token Facebook tidak valid atau sudah kadaluarsa.";
        }
        return {
          success: false,
          error: `Upload gagal: ${userMessage}`
        };
      }
      const postId = uploadResult.post_id || uploadResult.id;
      const photoId = uploadResult.id;
      const photoUrl = `https://www.facebook.com/${pageId}/photos/${photoId}`;
      logger?.info("\u2705 [facebookUploadPhoto] Photo uploaded successfully:", {
        photoId,
        postId,
        photoUrl
      });
      try {
        fs.unlinkSync(context.photoPath);
        logger?.info("\u{1F5D1}\uFE0F [facebookUploadPhoto] Temporary file cleaned up");
      } catch (cleanupError) {
        logger?.warn("\u26A0\uFE0F [facebookUploadPhoto] Failed to clean up temporary file:", cleanupError);
      }
      return {
        success: true,
        postId,
        photoUrl
      };
    } catch (error) {
      logger?.error("\u274C [facebookUploadPhoto] Error:", error);
      return {
        success: false,
        error: `Error: ${error.message}`
      };
    }
  }
});

const facebookShareToGroups = createTool({
  id: "facebook-share-to-groups",
  description: "Share a Facebook post to multiple Facebook Groups",
  inputSchema: z.object({
    videoUrl: z.string().describe("URL of the video post to share"),
    videoId: z.string().describe("Facebook video ID"),
    message: z.string().optional().describe("Additional message to include when sharing")
  }),
  outputSchema: z.object({
    success: z.boolean(),
    totalGroups: z.number(),
    successCount: z.number(),
    failCount: z.number(),
    results: z.array(z.object({
      groupId: z.string(),
      success: z.boolean(),
      postId: z.string().optional(),
      error: z.string().optional()
    }))
  }),
  execute: async ({ context, mastra }) => {
    const logger = mastra?.getLogger();
    logger?.info("\u{1F527} [facebookShareToGroups] Starting execution with params:", context);
    let pageAccessToken;
    try {
      const credentials = await getFacebookCredentials(logger);
      pageAccessToken = credentials.pageAccessToken;
    } catch (error) {
      logger?.error("\u274C [facebookShareToGroups] Failed to get Facebook credentials:", error.message);
      return {
        success: false,
        totalGroups: 0,
        successCount: 0,
        failCount: 0,
        results: []
      };
    }
    try {
      const projectRoot = process.env.REPL_HOME || "/home/runner/workspace";
      const groupsFilePath = path.join(projectRoot, "groups.txt");
      logger?.info("\u{1F50D} [facebookShareToGroups] Checking groups.txt file...", {
        path: groupsFilePath,
        cwd: process.cwd(),
        exists: fs.existsSync(groupsFilePath)
      });
      if (!fs.existsSync(groupsFilePath)) {
        logger?.warn("\u26A0\uFE0F [facebookShareToGroups] groups.txt not found, creating empty file");
        fs.writeFileSync(groupsFilePath, "# Tambahkan Facebook Group IDs di sini, satu per baris\n");
        return {
          success: true,
          totalGroups: 0,
          successCount: 0,
          failCount: 0,
          results: []
        };
      }
      const groupsContent = fs.readFileSync(groupsFilePath, "utf-8");
      logger?.info("\u{1F4C4} [facebookShareToGroups] File content loaded", {
        contentLength: groupsContent.length,
        lines: groupsContent.split("\n").length
      });
      const groupIds = groupsContent.split("\n").map((line) => line.trim()).filter((line) => line && !line.startsWith("#"));
      logger?.info("\u{1F4DD} [facebookShareToGroups] Parsed group IDs", {
        count: groupIds.length,
        firstFew: groupIds.slice(0, 3),
        allIds: groupIds
      });
      if (groupIds.length === 0) {
        logger?.warn("\u26A0\uFE0F [facebookShareToGroups] No group IDs found in groups.txt");
        logger?.warn("\u26A0\uFE0F [facebookShareToGroups] Raw content preview:", {
          preview: groupsContent.substring(0, 200)
        });
        return {
          success: true,
          totalGroups: 0,
          successCount: 0,
          failCount: 0,
          results: []
        };
      }
      logger?.info("\u2705 [facebookShareToGroups] Found groups to share:", { count: groupIds.length });
      const shareMessage = context.message || `\u{1F525} Video baru! Tonton sekarang: ${context.videoUrl}`;
      const results = [];
      let successCount = 0;
      let failCount = 0;
      for (const groupId of groupIds) {
        logger?.info(`\u{1F4E4} [facebookShareToGroups] Sharing to group ${groupId}...`);
        try {
          const shareUrl = `https://graph.facebook.com/v19.0/${groupId}/feed`;
          const shareResponse = await fetch(shareUrl, {
            method: "POST",
            headers: {
              "Content-Type": "application/json"
            },
            body: JSON.stringify({
              message: shareMessage,
              link: context.videoUrl,
              access_token: pageAccessToken
            })
          });
          const shareResult = await shareResponse.json();
          if (shareResponse.ok && shareResult.id) {
            logger?.info(`\u2705 [facebookShareToGroups] Successfully shared to group ${groupId}:`, shareResult.id);
            results.push({
              groupId,
              success: true,
              postId: shareResult.id
            });
            successCount++;
          } else {
            logger?.error(`\u274C [facebookShareToGroups] Failed to share to group ${groupId}:`, shareResult);
            results.push({
              groupId,
              success: false,
              error: shareResult.error?.message || "Unknown error"
            });
            failCount++;
          }
          await new Promise((resolve) => setTimeout(resolve, 1e3));
        } catch (error) {
          logger?.error(`\u274C [facebookShareToGroups] Error sharing to group ${groupId}:`, error);
          results.push({
            groupId,
            success: false,
            error: error.message
          });
          failCount++;
        }
      }
      logger?.info("\u2705 [facebookShareToGroups] Sharing complete:", {
        totalGroups: groupIds.length,
        successCount,
        failCount
      });
      return {
        success: successCount > 0,
        totalGroups: groupIds.length,
        successCount,
        failCount,
        results
      };
    } catch (error) {
      logger?.error("\u274C [facebookShareToGroups] Error:", error);
      return {
        success: false,
        totalGroups: 0,
        successCount: 0,
        failCount: 0,
        results: []
      };
    }
  }
});

const telegramSendMessage = createTool({
  id: "telegram-send-message",
  description: "Send a message to a Telegram chat",
  inputSchema: z.object({
    chatId: z.union([z.string(), z.number()]).describe("Telegram chat ID to send message to"),
    message: z.string().describe("Message text to send"),
    parseMode: z.enum(["HTML", "Markdown", "MarkdownV2"]).optional().describe("Message parse mode")
  }),
  outputSchema: z.object({
    success: z.boolean(),
    messageId: z.number().optional(),
    error: z.string().optional()
  }),
  execute: async ({ context, mastra }) => {
    const logger = mastra?.getLogger();
    logger?.info("\u{1F527} [telegramSendMessage] Starting execution with params:", {
      chatId: context.chatId,
      messageLength: context.message.length
    });
    const token = process.env.TELEGRAM_BOT_TOKEN?.trim();
    if (!token) {
      logger?.error("\u274C [telegramSendMessage] TELEGRAM_BOT_TOKEN not found");
      return {
        success: false,
        error: "TELEGRAM_BOT_TOKEN tidak ditemukan di environment variables"
      };
    }
    try {
      logger?.info("\u{1F4DD} [telegramSendMessage] Sending message to Telegram...");
      logger?.info("\u{1F511} [telegramSendMessage] Token length:", token.length);
      const sendUrl = `https://api.telegram.org/bot${token}/sendMessage`;
      const response = await fetch(sendUrl, {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          chat_id: context.chatId,
          text: context.message,
          parse_mode: context.parseMode || void 0
        })
      });
      const result = await response.json();
      if (!response.ok || !result.ok) {
        logger?.error("\u274C [telegramSendMessage] Failed to send message:", result);
        return {
          success: false,
          error: result.description || "Gagal mengirim pesan"
        };
      }
      logger?.info("\u2705 [telegramSendMessage] Message sent successfully:", {
        messageId: result.result.message_id
      });
      return {
        success: true,
        messageId: result.result.message_id
      };
    } catch (error) {
      logger?.error("\u274C [telegramSendMessage] Error:", error);
      return {
        success: false,
        error: `Error: ${error.message}`
      };
    }
  }
});

const generateEngagingCaption = createTool({
  id: "generate-engaging-caption",
  description: "Generate an engaging, viral-worthy caption with emojis and call-to-action to maximize video engagement and views",
  inputSchema: z.object({
    title: z.string().describe("Video title or main topic"),
    category: z.enum([
      "meme",
      "comedy",
      "tutorial",
      "motivasi",
      "gaming",
      "lifestyle",
      "teknologi",
      "kuliner",
      "travel",
      "music",
      "sports",
      "brainrot",
      "absurd",
      "random",
      "perfectcut",
      "general"
    ]).optional().default("general").describe("Content category for targeted caption"),
    language: z.enum(["id", "en"]).optional().default("id").describe("Caption language")
  }),
  outputSchema: z.object({
    caption: z.string(),
    category: z.string(),
    hasEmoji: z.boolean(),
    hasCallToAction: z.boolean()
  }),
  execute: async ({ context, mastra }) => {
    const logger = mastra?.getLogger();
    logger?.info("\u{1F527} [generateEngagingCaption] Starting execution with params:", context);
    const { title, category, language } = context;
    const categoryEmojis = {
      meme: ["\u{1F602}", "\u{1F923}", "\u{1F480}", "\u{1F62D}", "\u{1F525}", "\u{1F4AF}"],
      comedy: ["\u{1F604}", "\u{1F923}", "\u{1F606}", "\u{1F602}", "\u{1F3AD}", "\u2728"],
      tutorial: ["\u{1F4DA}", "\u2705", "\u{1F4A1}", "\u{1F3AF}", "\u{1F468}\u200D\u{1F3EB}", "\u{1F4D6}"],
      motivasi: ["\u{1F4AA}", "\u{1F525}", "\u26A1", "\u{1F31F}", "\u2728", "\u{1F680}"],
      gaming: ["\u{1F3AE}", "\u{1F579}\uFE0F", "\u{1F47E}", "\u{1F3AF}", "\u{1F3C6}", "\u2694\uFE0F"],
      lifestyle: ["\u2728", "\u{1F4AB}", "\u{1F308}", "\u{1F495}", "\u{1F338}", "\u{1F380}"],
      teknologi: ["\u{1F4BB}", "\u{1F4F1}", "\u{1F916}", "\u26A1", "\u{1F527}", "\u{1F680}"],
      kuliner: ["\u{1F354}", "\u{1F355}", "\u{1F35C}", "\u{1F60B}", "\u{1F924}", "\u{1F525}"],
      travel: ["\u2708\uFE0F", "\u{1F30D}", "\u{1F5FA}\uFE0F", "\u{1F4F8}", "\u{1F305}", "\u{1F3D6}\uFE0F"],
      music: ["\u{1F3B5}", "\u{1F3B6}", "\u{1F3A4}", "\u{1F3A7}", "\u{1F50A}", "\u{1F4BF}"],
      sports: ["\u26BD", "\u{1F3C0}", "\u{1F3C6}", "\u{1F4AA}", "\u{1F525}", "\u26A1"],
      brainrot: ["\u{1F9E0}", "\u{1F480}", "\u{1F62D}", "\u{1F923}", "\u{1F525}", "\u{1F4AF}"],
      absurd: ["\u{1F602}", "\u{1F923}", "\u{1F480}", "\u{1F62D}", "\u{1F525}", "\u{1F3AD}"],
      random: ["\u{1F3B2}", "\u{1F92A}", "\u{1F602}", "\u{1F480}", "\u{1F525}", "\u2728"],
      perfectcut: ["\u2702\uFE0F", "\u23F0", "\u{1F602}", "\u{1F480}", "\u{1F525}", "\u{1F3AF}"],
      general: ["\u2728", "\u{1F525}", "\u{1F4AF}", "\u{1F440}", "\u{1F3AF}", "\u{1F4AB}"]
    };
    const ctaTemplatesID = [
      "Tag teman kamu! \u{1F465}",
      "Share ke teman-teman! \u{1F4E4}",
      "Jangan lupa like dan share! \u2764\uFE0F",
      "Kalau suka, share ya! \u{1F60A}",
      "Tag yang harus lihat ini! \u{1F447}",
      "Double tap kalau setuju! \u{1F4AF}",
      "Simpan untuk nanti! \u{1F4CC}",
      "Share ke story kamu! \u{1F4F1}",
      "Comment di bawah! \u{1F4AC}",
      "Follow untuk konten lebih seru! \u2B50"
    ];
    const ctaTemplatesEN = [
      "Tag your friends! \u{1F465}",
      "Share with friends! \u{1F4E4}",
      "Don't forget to like and share! \u2764\uFE0F",
      "If you like it, share it! \u{1F60A}",
      "Tag someone who needs to see this! \u{1F447}",
      "Double tap if you agree! \u{1F4AF}",
      "Save for later! \u{1F4CC}",
      "Share to your story! \u{1F4F1}",
      "Comment below! \u{1F4AC}",
      "Follow for more! \u2B50"
    ];
    const hookTemplatesID = {
      meme: [
        "POV:",
        "Anjir! \u{1F62D}",
        "Gak kuat! \u{1F480}",
        "Receh banget! \u{1F923}",
        "Random!",
        "Absurd! \u{1F602}",
        "Brainrot content! \u{1F525}",
        "Ini kenapa sih! \u{1F923}"
      ],
      comedy: [
        "Dijamin ngakak! \u{1F604}",
        "Lucu banget anjir! \u{1F923}",
        "Nonton sampe abis ya! \u{1F606}",
        "Prepare to laugh! \u{1F3AD}"
      ],
      tutorial: [
        "Tips: ",
        "Cara mudah: ",
        "Tutorial lengkap: ",
        "Belajar yuk: ",
        "Step by step: "
      ],
      motivasi: [
        "Semangat! \u{1F4AA}",
        "Kamu pasti bisa! \u{1F525}",
        "Inspirasi hari ini: ",
        "Jangan menyerah! \u26A1"
      ],
      gaming: [
        "Gameplay epic! \u{1F3AE}",
        "Pro player move! \u{1F3C6}",
        "GG banget! \u{1F579}\uFE0F",
        "Watch this! \u{1F47E}"
      ],
      brainrot: [
        "Brainrot alert! \u{1F9E0}",
        "Random banget! \u{1F923}",
        "POV:",
        "Absurd! \u{1F62D}",
        "Receh! \u{1F480}"
      ],
      absurd: [
        "Absurd! \u{1F602}",
        "Random! \u{1F923}",
        "Gak nyambung! \u{1F62D}",
        "Chaos! \u{1F480}",
        "Kocak! \u{1F525}"
      ],
      random: [
        "Random! \u{1F3B2}",
        "Unexpected! \u{1F602}",
        "Plot twist! \u{1F923}",
        "Chaos! \u{1F480}"
      ],
      perfectcut: [
        "Perfect cut! \u2702\uFE0F",
        "Timing sempurna! \u23F0",
        "Cut di saat yang tepat! \u{1F602}"
      ],
      general: [
        "Cek ini! ",
        "Wajib nonton! ",
        "Jangan skip! ",
        "Amazing! "
      ]
    };
    const hookTemplatesEN = {
      meme: [
        "This is hilarious! \u{1F602}",
        "So relatable! \u{1F923}",
        "POV:",
        "Can't stop laughing! \u{1F480}",
        "Big mood! \u{1F62D}"
      ],
      comedy: [
        "Guaranteed laughs! \u{1F604}",
        "This is so funny! \u{1F923}",
        "Watch till the end! \u{1F606}"
      ],
      tutorial: [
        "Quick tip: ",
        "Easy way to: ",
        "Complete tutorial: ",
        "Learn how to: "
      ],
      general: [
        "Check this out! ",
        "Must watch! ",
        "Don't skip! ",
        "Amazing! "
      ]
    };
    const emojis = categoryEmojis[category] || categoryEmojis.general;
    const randomEmoji = emojis[Math.floor(Math.random() * emojis.length)];
    const randomEmoji2 = emojis[Math.floor(Math.random() * emojis.length)];
    const ctaTemplates = language === "id" ? ctaTemplatesID : ctaTemplatesEN;
    const randomCTA = ctaTemplates[Math.floor(Math.random() * ctaTemplates.length)];
    const hookTemplates = language === "id" ? hookTemplatesID[category] || hookTemplatesID.general : hookTemplatesEN[category] || hookTemplatesEN.general;
    const randomHook = hookTemplates[Math.floor(Math.random() * hookTemplates.length)];
    let caption = "";
    if (!randomHook.toLowerCase().includes(title.toLowerCase().substring(0, 10))) {
      caption += `${randomHook} ${randomEmoji}

`;
    }
    caption += `${title} ${randomEmoji2}

`;
    caption += `${randomCTA}

`;
    if (language === "id") {
      caption += `\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501
`;
      caption += `\u{1F4AC} Komen pendapat kamu!
`;
      caption += `\u2764\uFE0F Like kalau suka!
`;
      caption += `\u{1F4E4} Share ke teman-teman!
`;
    } else {
      caption += `\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501
`;
      caption += `\u{1F4AC} Comment your thoughts!
`;
      caption += `\u2764\uFE0F Like if you enjoyed!
`;
      caption += `\u{1F4E4} Share with friends!
`;
    }
    logger?.info("\u2705 [generateEngagingCaption] Caption generated successfully", {
      captionLength: caption.length,
      category,
      hasEmoji: true,
      hasCallToAction: true
    });
    return {
      caption,
      category,
      hasEmoji: true,
      hasCallToAction: true
    };
  }
});

const generateTrendingHashtags = createTool({
  id: "generate-trending-hashtags",
  description: "Generate trending and relevant hashtags to maximize video discoverability and reach on Facebook",
  inputSchema: z.object({
    title: z.string().describe("Video title or main topic"),
    category: z.enum([
      "meme",
      "comedy",
      "tutorial",
      "motivasi",
      "gaming",
      "lifestyle",
      "teknologi",
      "kuliner",
      "travel",
      "music",
      "sports",
      "brainrot",
      "absurd",
      "random",
      "perfectcut",
      "general"
    ]).optional().default("general").describe("Content category"),
    language: z.enum(["id", "en", "both"]).optional().default("both").describe("Hashtag language preference"),
    maxHashtags: z.number().optional().default(15).describe("Maximum number of hashtags to generate")
  }),
  outputSchema: z.object({
    hashtags: z.string(),
    count: z.number(),
    categories: z.array(z.string())
  }),
  execute: async ({ context, mastra }) => {
    const logger = mastra?.getLogger();
    logger?.info("\u{1F527} [generateTrendingHashtags] Starting execution with params:", context);
    const { title, category, language, maxHashtags } = context;
    const categoryHashtags = {
      meme: {
        id: ["memeindo", "memeabsurd", "memeindonesia", "randomvideo", "brainrot", "humorabsurd", "videolucu", "randompost", "perfectcut", "humorreceh", "ngakak", "ketawa"],
        en: ["memes", "funnymemes", "absurdhumor", "brainrot", "randomvideos", "perfectcut", "dankmemes", "memesdaily"],
        universal: ["reels", "video"]
      },
      comedy: {
        id: ["comedy", "lucu", "komedi", "humor", "ngakak", "kocak", "lawak"],
        en: ["comedy", "funny", "humor", "hilarious", "laugh", "jokes"],
        universal: ["viral", "entertainment", "funnyvideos", "lol"]
      },
      tutorial: {
        id: ["tutorial", "tips", "belajar", "edukasi", "howto", "caranya", "panduan"],
        en: ["tutorial", "howto", "learn", "education", "tips", "guide", "diy"],
        universal: ["educational", "learning", "knowledge", "skills"]
      },
      motivasi: {
        id: ["motivasi", "inspirasi", "semangat", "sukses", "quotes", "bijak", "positif"],
        en: ["motivation", "inspiration", "success", "mindset", "goals", "positive"],
        universal: ["motivated", "inspired", "hustle", "grind", "nevergiveup"]
      },
      gaming: {
        id: ["gaming", "game", "gamers", "mobilelegends", "pubg", "freefire", "esports"],
        en: ["gaming", "gamer", "gameplay", "videogames", "esports", "twitch"],
        universal: ["gamingcommunity", "gaminglife", "pro", "gg"]
      },
      lifestyle: {
        id: ["lifestyle", "kehidupan", "daily", "vlog", "ootd", "aesthetic"],
        en: ["lifestyle", "life", "daily", "vlog", "aesthetic", "vibes"],
        universal: ["instagood", "photooftheday", "love", "beautiful"]
      },
      teknologi: {
        id: ["teknologi", "tech", "gadget", "hp", "smartphone", "tipsteknologi"],
        en: ["technology", "tech", "gadgets", "innovation", "techreview"],
        universal: ["techy", "instatech", "android", "ios"]
      },
      kuliner: {
        id: ["kuliner", "makanan", "food", "jajanan", "makananenak", "foodie"],
        en: ["food", "foodie", "foodporn", "yummy", "delicious", "instafood"],
        universal: ["foodlover", "foodstagram", "foodblogger"]
      },
      travel: {
        id: ["travel", "traveling", "jalan", "wisata", "liburan", "explore"],
        en: ["travel", "traveling", "wanderlust", "adventure", "vacation"],
        universal: ["travelphotography", "instatravel", "travelgram"]
      },
      music: {
        id: ["musik", "lagu", "music", "song", "cover", "singing"],
        en: ["music", "song", "musician", "singer", "cover", "musicvideo"],
        universal: ["musiclover", "instamusic", "musicislife"]
      },
      sports: {
        id: ["olahraga", "sport", "fitness", "workout", "gym", "sehat"],
        en: ["sports", "fitness", "workout", "gym", "athlete", "training"],
        universal: ["fitnessmotivation", "sport", "healthy"]
      },
      brainrot: {
        id: ["brainrot", "brainrotmeme", "randomvideo", "absurd", "receh"],
        en: ["brainrot", "brainrotmemes", "randomcontent"],
        universal: ["reels"]
      },
      absurd: {
        id: ["humorabsurd", "memeabsurd", "absurd", "kocak", "receh"],
        en: ["absurdhumor", "absurdmemes", "randomhumor"],
        universal: ["video"]
      },
      random: {
        id: ["randomvideo", "randompost", "randomcontent", "videorandom"],
        en: ["randomvideos", "randomcontent", "randomstuff"],
        universal: ["reels"]
      },
      perfectcut: {
        id: ["perfectcut", "perfectlycut", "videolucu", "cutperfect"],
        en: ["perfectcut", "perfectlycutscreams", "perfectlycutvideo"],
        universal: ["video"]
      },
      general: {
        id: ["video", "reels", "konten", "keren", "seru", "indonesia"],
        en: ["video", "reels", "content", "cool", "awesome"],
        universal: ["videolucu", "randomvideo"]
      }
    };
    const globalTrending = [
      "reels",
      "video",
      "videolucu",
      "randomvideo",
      "memeindo"
    ];
    const hashtagSet = /* @__PURE__ */ new Set();
    const categories = [];
    const categoryData = categoryHashtags[category] || categoryHashtags.general;
    if (language === "id" || language === "both") {
      categoryData.id.forEach((tag) => hashtagSet.add(tag));
      categories.push("category-id");
    }
    if (language === "en" || language === "both") {
      categoryData.en.forEach((tag) => hashtagSet.add(tag));
      categories.push("category-en");
    }
    categoryData.universal.forEach((tag) => hashtagSet.add(tag));
    categories.push("universal");
    const titleWords = title.toLowerCase().replace(/[^\w\s]/g, "").split(/\s+/).filter((word) => word.length > 3 && word.length < 20);
    titleWords.forEach((word) => {
      if (hashtagSet.size < maxHashtags) {
        hashtagSet.add(word);
      }
    });
    categories.push("title-keywords");
    for (const tag of globalTrending) {
      if (hashtagSet.size >= maxHashtags) break;
      hashtagSet.add(tag);
    }
    categories.push("global-trending");
    const hashtagArray = Array.from(hashtagSet).slice(0, maxHashtags);
    const formattedHashtags = hashtagArray.map((tag) => `#${tag}`).join(" ");
    logger?.info("\u2705 [generateTrendingHashtags] Hashtags generated successfully", {
      count: hashtagArray.length,
      categories,
      preview: hashtagArray.slice(0, 5)
    });
    return {
      hashtags: formattedHashtags,
      count: hashtagArray.length,
      categories
    };
  }
});

const openai = createOpenAI({
  baseURL: process.env.OPENAI_BASE_URL || void 0,
  apiKey: process.env.OPENAI_API_KEY
});
const facebookVideoAgent = new Agent({
  name: "Facebook Media Upload Agent",
  instructions: `
    Anda adalah asisten yang membantu mengunggah media (video dan foto) dari Telegram ke Facebook Page dengan optimasi engagement otomatis.
    
    TUGAS UNTUK VIDEO:
    0. WAJIB: Generate caption menarik dan hashtag trending untuk maksimalkan engagement
    1. Download video dari Telegram menggunakan file_id yang diberikan
    2. Konversi video ke format yang kompatibel dengan Facebook (H.264/AAC) menggunakan FFmpeg
    3. Upload video hasil konversi ke Facebook Page dengan caption dan hashtag yang sudah dioptimasi
    4. Setelah berhasil upload, bagikan post video tersebut ke semua grup Facebook dengan caption optimal
    5. Kirim konfirmasi ke pengguna di Telegram dengan hasil operasi dan tips meningkatkan views
    
    TUGAS UNTUK FOTO:
    0. WAJIB: Generate caption menarik dan hashtag trending untuk maksimalkan engagement
    1. Download foto dari Telegram menggunakan file_id yang diberikan
    2. Upload foto langsung ke Facebook Page dengan caption dan hashtag yang sudah dioptimasi (SKIP konversi FFmpeg)
    3. Kirim konfirmasi ke pengguna di Telegram dengan hasil operasi dan tips meningkatkan engagement
    
    OPTIMASI ENGAGEMENT (PENTING!):
    - SELALU gunakan generate-engaging-caption untuk membuat caption yang menarik dengan emoji dan call-to-action
    - SELALU gunakan generate-trending-hashtags untuk hashtag yang relevan dan viral
    - Deteksi kategori konten (meme, gaming, tutorial, dll) dari judul untuk optimasi yang tepat
    - Caption dan hashtag yang dioptimasi ini akan meningkatkan discoverability dan engagement secara signifikan
    
    PETUNJUK PENTING:
    - Gunakan tools yang tersedia untuk setiap langkah SECARA BERURUTAN
    - UNTUK VIDEO: WAJIB gunakan ffmpeg-convert-video sebelum upload untuk menghindari error "file corrupt"
    - UNTUK FOTO: JANGAN gunakan ffmpeg-convert-video, langsung upload dengan facebook-upload-photo
    - Berikan respons dalam Bahasa Indonesia yang ramah dan jelas
    - Jika ada error, jelaskan dengan bahasa yang mudah dipahami
    - Selalu konfirmasi hasil akhir ke pengguna dengan tips engagement
    
    TOOLS UNTUK VIDEO (gunakan urutan ini):
    1. generate-engaging-caption: buat caption menarik dengan emoji dan CTA
    2. generate-trending-hashtags: buat hashtag trending untuk maksimalkan reach
    3. telegram-download-video: download video dari Telegram
    4. ffmpeg-convert-video: konversi video ke format Facebook-compatible (WAJIB untuk video)
    5. facebook-upload-video-smart: upload video ke Facebook Page (gunakan caption + hashtag yang sudah dioptimasi)
    6. facebook-share-to-groups: share post video ke grup-grup Facebook (gunakan caption + hashtag optimal)
    7. telegram-send-message: kirim pesan konfirmasi dengan tips meningkatkan views
    
    TOOLS UNTUK FOTO (gunakan urutan ini):
    1. generate-engaging-caption: buat caption menarik dengan emoji dan CTA
    2. generate-trending-hashtags: buat hashtag trending untuk maksimalkan reach
    3. telegram-download-photo: download foto dari Telegram
    4. facebook-upload-photo: upload foto ke Facebook Page (gunakan caption + hashtag yang sudah dioptimasi)
    5. telegram-send-message: kirim pesan konfirmasi dengan tips meningkatkan engagement
    
    PENTING: 
    - FFmpeg (ffmpeg-convert-video) HANYA untuk video, JANGAN gunakan untuk foto!
    - Sharing ke grup (facebook-share-to-groups) saat ini hanya tersedia untuk video.
    - Caption dan hashtag optimization adalah WAJIB untuk semua upload!
  `,
  model: openai.responses("gpt-4o"),
  tools: {
    // Engagement optimization tools (use FIRST!)
    generateEngagingCaption,
    generateTrendingHashtags,
    // Video tools
    telegramDownloadVideo,
    ffmpegConvertVideo,
    facebookUploadVideoSmart,
    facebookShareToGroups,
    // Photo tools
    telegramDownloadPhoto,
    facebookUploadPhoto,
    // Shared tools
    telegramSendMessage
  },
  memory: new Memory({
    options: {
      threads: {
        generateTitle: true
      },
      lastMessages: 10
    },
    storage: sharedPostgresStorage
  })
});

const detectCategory = (title, logger) => {
  logger?.info("\u{1F50D} [detectCategory] Starting category detection...", { title });
  if (typeof title !== "string" || title.trim() === "") {
    logger?.warn('\u26A0\uFE0F [detectCategory] Empty or invalid title, defaulting to "general"');
    return "general";
  }
  const titleLower = title.toLowerCase();
  logger?.info("\u{1F4DD} [detectCategory] Normalized title:", { titleLower });
  if (titleLower.match(/brainrot|brain rot|brainrotmeme/)) {
    logger?.info("\u2705 [detectCategory] Detected category: brainrot (NEW CATEGORY)");
    return "brainrot";
  }
  if (titleLower.match(/perfect cut|perfectcut|perfectly cut|perfectlycut|timing/)) {
    logger?.info("\u2705 [detectCategory] Detected category: perfectcut (NEW CATEGORY)");
    return "perfectcut";
  }
  if (titleLower.match(/absurd|absur|chaos|receh/)) {
    logger?.info("\u2705 [detectCategory] Detected category: absurd (NEW CATEGORY)");
    return "absurd";
  }
  if (titleLower.match(/random|acak|unexpected/)) {
    logger?.info("\u2705 [detectCategory] Detected category: random (NEW CATEGORY)");
    return "random";
  }
  if (titleLower.match(/meme|lucu|ngakak|ketawa|🤣|😂/)) {
    logger?.info("\u2705 [detectCategory] Detected category: meme");
    return "meme";
  }
  if (titleLower.match(/comedy|komedi|lawak|humor/)) {
    logger?.info("\u2705 [detectCategory] Detected category: comedy");
    return "comedy";
  }
  if (titleLower.match(/tutorial|cara|tips|belajar|how to/)) {
    logger?.info("\u2705 [detectCategory] Detected category: tutorial");
    return "tutorial";
  }
  if (titleLower.match(/motivasi|inspirasi|semangat|sukses/)) {
    logger?.info("\u2705 [detectCategory] Detected category: motivasi");
    return "motivasi";
  }
  if (titleLower.match(/game|gaming|ml|pubg|ff|freefire/)) {
    logger?.info("\u2705 [detectCategory] Detected category: gaming");
    return "gaming";
  }
  if (titleLower.match(/lifestyle|vlog|daily|ootd/)) {
    logger?.info("\u2705 [detectCategory] Detected category: lifestyle");
    return "lifestyle";
  }
  if (titleLower.match(/teknologi|tech|gadget|hp|smartphone/)) {
    logger?.info("\u2705 [detectCategory] Detected category: teknologi");
    return "teknologi";
  }
  if (titleLower.match(/makanan|kuliner|food|makan/)) {
    logger?.info("\u2705 [detectCategory] Detected category: kuliner");
    return "kuliner";
  }
  if (titleLower.match(/travel|jalan|wisata|liburan/)) {
    logger?.info("\u2705 [detectCategory] Detected category: travel");
    return "travel";
  }
  if (titleLower.match(/musik|music|lagu|song/)) {
    logger?.info("\u2705 [detectCategory] Detected category: music");
    return "music";
  }
  if (titleLower.match(/olahraga|sport|fitness|gym/)) {
    logger?.info("\u2705 [detectCategory] Detected category: sports");
    return "sports";
  }
  logger?.info('\u26A1 [detectCategory] No specific category matched, defaulting to "general"');
  return "general";
};
const processMediaDirectly = async (inputData, mastra) => {
  const logger = mastra?.getLogger();
  const mediaType = inputData.mediaType || "video";
  logger?.info("\u26A0\uFE0F [AI Mode] FALLBACK - Running without AI, using direct tool calls");
  logger?.info(`\u{1F4DD} [processMediaDirectly] Starting direct ${mediaType} processing...`, { mediaType });
  let mediaUrl = "";
  let mediaId = "";
  let originalMediaPath = "";
  let convertedVideoPath = "";
  let downloadSuccess = false;
  let convertSuccess = false;
  let uploadSuccess = false;
  let shareResults = { totalGroups: 0, successCount: 0, failCount: 0 };
  let optimizedCaption = "";
  let optimizedHashtags = "";
  try {
    logger?.info("\u2728 [Step 0] Generating engaging caption and trending hashtags...");
    const safeTitle = inputData.title || "Media upload";
    const safeDescription = inputData.description || "";
    const category = detectCategory(safeTitle, logger);
    try {
      const captionResult = await generateEngagingCaption.execute({
        context: {
          title: safeTitle,
          category,
          language: "id"
        },
        mastra,
        runtimeContext: {}
      });
      const hashtagResult = await generateTrendingHashtags.execute({
        context: {
          title: safeTitle,
          category,
          language: "both",
          maxHashtags: 15
        },
        mastra,
        runtimeContext: {}
      });
      optimizedCaption = captionResult.caption;
      optimizedHashtags = hashtagResult.hashtags;
      logger?.info("\u2705 [Step 0] Caption and hashtags generated successfully", {
        category,
        captionLength: optimizedCaption.length,
        hashtagCount: hashtagResult.count
      });
    } catch (captionError) {
      logger?.warn("\u26A0\uFE0F [Step 0] Caption/hashtag generation failed, using user input as fallback", {
        error: captionError.message
      });
      optimizedCaption = safeTitle;
      optimizedHashtags = safeDescription;
      logger?.info("\u2705 [Step 0] Using fallback caption (user input)");
    }
    if (mediaType === "photo") {
      logger?.info("\u{1F4E5} [Step 1] Downloading photo from Telegram...");
      const downloadResult = await telegramDownloadPhoto.execute({
        context: {
          fileId: inputData.fileId,
          fileName: `photo_${Date.now()}`
          // Let the tool add the correct extension
        },
        mastra,
        runtimeContext: {}
      });
      if (!downloadResult.success || !downloadResult.filePath) {
        throw new Error(`Download foto gagal: ${downloadResult.error || "Unknown error"}`);
      }
      downloadSuccess = true;
      originalMediaPath = downloadResult.filePath;
      logger?.info("\u2705 [Step 1] Photo downloaded successfully:", originalMediaPath);
    } else {
      logger?.info("\u{1F4E5} [Step 1/5] Downloading video from Telegram...");
      const downloadResult = await telegramDownloadVideo.execute({
        context: {
          fileId: inputData.fileId,
          fileName: `video_${Date.now()}`
          // Let the tool add the correct extension
        },
        mastra,
        runtimeContext: {}
      });
      if (!downloadResult.success || !downloadResult.filePath) {
        throw new Error(`Download video gagal: ${downloadResult.error || "Unknown error"}`);
      }
      downloadSuccess = true;
      originalMediaPath = downloadResult.filePath;
      logger?.info("\u2705 [Step 1/5] Video downloaded successfully:", originalMediaPath);
    }
    if (mediaType === "video") {
      logger?.info("\u{1F3AC} [Step 2/5] Converting video to Facebook-compatible format...");
      const convertResult = await ffmpegConvertVideo.execute({
        context: {
          videoPath: originalMediaPath
        },
        mastra,
        runtimeContext: {}
      });
      if (!convertResult.success || !convertResult.convertedVideoPath) {
        throw new Error(`Konversi video gagal: ${convertResult.error || "Unknown error"}`);
      }
      convertSuccess = true;
      convertedVideoPath = convertResult.convertedVideoPath;
      logger?.info("\u2705 [Step 2/5] Video converted successfully:", convertedVideoPath);
    } else {
      logger?.info("\u23ED\uFE0F [Step 2] Skipping conversion for photo (not needed)");
      convertSuccess = true;
    }
    if (mediaType === "photo") {
      logger?.info("\u{1F4E4} [Step 2] Uploading photo to Facebook Page...");
      const fullCaption = `${optimizedCaption}

${optimizedHashtags}`;
      const uploadResult = await facebookUploadPhoto.execute({
        context: {
          photoPath: originalMediaPath,
          caption: fullCaption
        },
        mastra,
        runtimeContext: {}
      });
      if (!uploadResult.success || !uploadResult.photoUrl) {
        throw new Error(`Upload foto gagal: ${uploadResult.error || "Unknown error"}`);
      }
      uploadSuccess = true;
      mediaUrl = uploadResult.photoUrl;
      mediaId = uploadResult.postId;
      logger?.info("\u2705 [Step 2] Photo uploaded to Facebook:", mediaUrl);
    } else {
      logger?.info("\u{1F4E4} [Step 3/5] Uploading video to Facebook Page (smart upload)...");
      const fullDescription = `${optimizedCaption}

${optimizedHashtags}`;
      const uploadResult = await facebookUploadVideoSmart.execute({
        context: {
          videoPath: convertedVideoPath,
          // Use converted video instead of original
          title: inputData.title,
          description: fullDescription
        },
        mastra,
        runtimeContext: {}
      });
      if (!uploadResult.success || !uploadResult.videoUrl) {
        throw new Error(`Upload video gagal: ${uploadResult.error || "Unknown error"}`);
      }
      uploadSuccess = true;
      mediaUrl = uploadResult.videoUrl;
      mediaId = uploadResult.videoId;
      logger?.info("\u2705 [Step 3/5] Video uploaded to Facebook:", mediaUrl);
    }
    if (mediaType === "video") {
      logger?.info("\u{1F4E2} [Step 4/5] Sharing to Facebook Groups...");
      const shareMessage = `${optimizedCaption}

${optimizedHashtags}`;
      const shareResult = await facebookShareToGroups.execute({
        context: {
          videoUrl: mediaUrl,
          videoId: mediaId,
          message: shareMessage
        },
        mastra,
        runtimeContext: {}
      });
      shareResults = {
        totalGroups: shareResult.totalGroups,
        successCount: shareResult.successCount,
        failCount: shareResult.failCount
      };
      logger?.info("\u2705 [Step 4/5] Sharing complete:", shareResults);
    } else {
      logger?.info("\u23ED\uFE0F [Step 3] Skipping group sharing for photo (not implemented yet)");
      shareResults = { totalGroups: 0, successCount: 0, failCount: 0 };
    }
    const finalStep = mediaType === "photo" ? "[Step 3]" : "[Step 5/5]";
    logger?.info(`\u{1F4E8} ${finalStep} Sending confirmation to user...`);
    let confirmationMessage = "";
    if (mediaType === "photo") {
      confirmationMessage = `
\u2705 *Foto berhasil diupload dengan caption optimal!*

\u{1F4DD} *Caption yang digunakan:*
${optimizedCaption}

\u{1F3F7}\uFE0F *Hashtags:*
${optimizedHashtags}

\u{1F517} *Link Foto:*
${mediaUrl}

\u{1F4A1} *Tips Engagement:*
\u2022 Caption dan hashtag sudah dioptimasi untuk viral
\u2022 Like dan comment di post untuk boost algoritma
\u2022 Share ke story pribadi untuk reach maksimal

_Foto diproses dengan optimasi engagement otomatis_
      `.trim();
    } else {
      confirmationMessage = `
\u2705 *Video berhasil diupload dengan caption optimal!*

\u{1F4DD} *Caption yang digunakan:*
${optimizedCaption}

\u{1F3F7}\uFE0F *Hashtags:*
${optimizedHashtags}

\u{1F517} *Link Video:*
${mediaUrl}

\u{1F4CA} *Hasil Sharing ke Grup:*
\u2022 Total grup: ${shareResults.totalGroups}
\u2022 Berhasil: ${shareResults.successCount}
\u2022 Gagal: ${shareResults.failCount}

${shareResults.totalGroups === 0 ? "\u26A0\uFE0F Tidak ada grup Facebook di groups.txt" : ""}
${shareResults.successCount > 0 ? "\u2705 Video sudah dibagikan ke grup Facebook!" : ""}

\u{1F4A1} *Tips Meningkatkan Views:*
\u2022 Caption dan hashtag sudah dioptimasi untuk viral
\u2022 ${shareResults.successCount === 0 ? "Share manual ke grup pribadi atau story untuk boost awal" : "Like dan comment di post untuk boost algoritma"}
\u2022 Tag teman-teman di komentar untuk reach organik
\u2022 Post di waktu prime time (18:00-22:00 WIB)

_Video diproses dengan optimasi engagement otomatis_
      `.trim();
    }
    await telegramSendMessage.execute({
      context: {
        chatId: inputData.chatId,
        message: confirmationMessage
      },
      mastra,
      runtimeContext: {}
    });
    logger?.info(`\u2705 ${finalStep} Confirmation sent to user`);
    logger?.info(`\u{1F5D1}\uFE0F [Cleanup] Deleting temporary ${mediaType} files...`);
    try {
      if (originalMediaPath && fs.existsSync(originalMediaPath)) {
        fs.unlinkSync(originalMediaPath);
        logger?.info(`\u2705 [Cleanup] Deleted original ${mediaType}:`, originalMediaPath);
      }
      if (convertedVideoPath && fs.existsSync(convertedVideoPath)) {
        fs.unlinkSync(convertedVideoPath);
        logger?.info("\u2705 [Cleanup] Deleted converted video:", convertedVideoPath);
      }
    } catch (cleanupError) {
      logger?.warn("\u26A0\uFE0F [Cleanup] Failed to delete temporary files:", cleanupError.message);
    }
    return {
      success: true,
      mediaUrl,
      shareResults,
      message: confirmationMessage
    };
  } catch (error) {
    logger?.error(`\u274C [processMediaDirectly] Error processing ${mediaType}:`, error);
    logger?.info(`\u{1F5D1}\uFE0F [Cleanup] Deleting temporary ${mediaType} files (error cleanup)...`);
    try {
      if (originalMediaPath && fs.existsSync(originalMediaPath)) {
        fs.unlinkSync(originalMediaPath);
        logger?.info(`\u2705 [Cleanup] Deleted original ${mediaType}:`, originalMediaPath);
      }
      if (convertedVideoPath && fs.existsSync(convertedVideoPath)) {
        fs.unlinkSync(convertedVideoPath);
        logger?.info("\u2705 [Cleanup] Deleted converted video:", convertedVideoPath);
      }
    } catch (cleanupError) {
      logger?.warn("\u26A0\uFE0F [Cleanup] Failed to delete temporary files:", cleanupError.message);
    }
    try {
      const mediaTypeLabel = mediaType === "photo" ? "foto" : "video";
      let errorMessage = `\u274C *Maaf, terjadi error saat memproses ${mediaTypeLabel}*

`;
      if (!downloadSuccess) {
        errorMessage += `\u{1F4E5} Download ${mediaTypeLabel}: GAGAL
${error.message}

`;
      } else if (mediaType === "video" && !convertSuccess) {
        errorMessage += `\u{1F4E5} Download video: SUKSES
\u{1F3AC} Konversi video: GAGAL
${error.message}

`;
      } else if (!uploadSuccess) {
        if (mediaType === "photo") {
          errorMessage += `\u{1F4E5} Download foto: SUKSES
\u{1F4E4} Upload ke Facebook: GAGAL
${error.message}

`;
        } else {
          errorMessage += `\u{1F4E5} Download video: SUKSES
\u{1F3AC} Konversi video: SUKSES
\u{1F4E4} Upload ke Facebook: GAGAL
${error.message}

`;
        }
      } else {
        errorMessage += `\u{1F4E5} Download: SUKSES
${mediaType === "video" ? "\u{1F3AC} Konversi: SUKSES\n" : ""}\u{1F4E4} Upload: SUKSES
\u{1F4E2} Share: ERROR
${error.message}

`;
      }
      errorMessage += `Silakan coba lagi atau hubungi admin.`;
      await telegramSendMessage.execute({
        context: {
          chatId: inputData.chatId,
          message: errorMessage
        },
        mastra,
        runtimeContext: {}
      });
    } catch (notifError) {
      logger?.error("\u274C Failed to send error notification:", notifError);
    }
    return {
      success: false,
      shareResults,
      message: `Error: ${error.message}`
    };
  }
};
const processMediaUpload = createStep({
  id: "process-video-upload",
  // Keep same ID for backwards compatibility
  description: "Download media (video/photo) dari Telegram, upload ke Facebook Page, share ke groups (video only), dan kirim konfirmasi",
  inputSchema: z.object({
    threadId: z.string().describe("Thread ID untuk memory management"),
    chatId: z.union([z.string(), z.number()]).describe("Telegram chat ID pengirim media"),
    fileId: z.string().describe("Telegram file_id dari media (video atau photo)"),
    mediaType: z.enum(["video", "photo"]).default("video").describe("Type of media: video or photo"),
    title: z.string().describe("Judul/caption untuk media"),
    description: z.string().describe("Deskripsi/caption media dengan hashtags"),
    userName: z.string().optional().describe("Username pengirim")
  }),
  outputSchema: z.object({
    success: z.boolean(),
    mediaUrl: z.string().optional(),
    shareResults: z.object({
      totalGroups: z.number(),
      successCount: z.number(),
      failCount: z.number()
    }).optional(),
    message: z.string()
  }),
  execute: async ({ inputData, mastra }) => {
    const logger = mastra?.getLogger();
    const mediaType = inputData.mediaType || "video";
    logger?.info(`\u{1F680} [processMediaUpload] Starting ${mediaType} upload process...`, {
      threadId: inputData.threadId,
      chatId: inputData.chatId,
      mediaType,
      title: inputData.title
    });
    const hasOpenAIKey = !!process.env.OPENAI_API_KEY && process.env.OPENAI_API_KEY.trim() !== "";
    const useAI = hasOpenAIKey && process.env.AI_FALLBACK_ENABLED !== "true";
    logger?.info(`[AI] Mode: ${useAI ? "AI ACTIVE" : "FALLBACK (Direct Tools)"}`);
    logger?.info(`[AI] OpenAI Key: ${hasOpenAIKey ? "Present" : "Missing"}`);
    logger?.info(`[AI] Fallback Enabled: ${process.env.AI_FALLBACK_ENABLED || "default (false)"}`);
    if (!useAI || !hasOpenAIKey) {
      logger?.info("\u26A0\uFE0F AI sedang offline atau dinonaktifkan, menggunakan mode fallback");
      return await processMediaDirectly(inputData, mastra);
    }
    try {
      const prompt = mediaType === "photo" ? `
Saya memiliki foto dari Telegram yang perlu di-upload ke Facebook Page.

Detail:
- File ID Telegram: ${inputData.fileId}
- Type: Photo
- Caption: ${inputData.title}
- Deskripsi: ${inputData.description}
- Chat ID pengirim: ${inputData.chatId}

Tolong lakukan langkah-langkah berikut secara berurutan:

1. Download foto dari Telegram menggunakan file_id tersebut
2. Upload foto ke Facebook Page dengan caption yang diberikan
3. Kirim pesan konfirmasi ke chat ID ${inputData.chatId} yang berisi:
   - Link foto di Facebook
   - Pesan yang ramah dan informatif dalam Bahasa Indonesia

PENTING: Jangan gunakan FFmpeg untuk foto, langsung upload saja.

Jika ada error di langkah manapun, laporkan error dalam pesan konfirmasi.
        ` : `
Saya memiliki video dari Telegram yang perlu di-upload ke Facebook Page dan dibagikan ke grup-grup Facebook.

Detail:
- File ID Telegram: ${inputData.fileId}
- Type: Video
- Judul: ${inputData.title}
- Deskripsi: ${inputData.description}
- Chat ID pengirim: ${inputData.chatId}

Tolong lakukan langkah-langkah berikut secara berurutan:

1. Download video dari Telegram menggunakan file_id tersebut
2. Konversi video ke format Facebook-compatible menggunakan FFmpeg (WAJIB)
3. Upload video hasil konversi ke Facebook Page dengan judul dan deskripsi yang diberikan
4. Setelah berhasil upload, bagikan post video ke semua grup Facebook yang ada di groups.txt
5. Kirim pesan konfirmasi ke chat ID ${inputData.chatId} yang berisi:
   - Link video di Facebook
   - Jumlah grup yang berhasil/gagal di-share
   - Pesan yang ramah dan informatif dalam Bahasa Indonesia

Jika ada error di langkah manapun, tetap lanjutkan ke langkah berikutnya yang masih bisa dilakukan, dan laporkan semua error dalam pesan konfirmasi.

Berikan saya ringkasan hasil akhir dari semua langkah tersebut.
        `;
      logger?.info(`\u{1F4DD} [processMediaUpload] Calling AI agent to process ${mediaType}...`);
      const response = await facebookVideoAgent.generateLegacy(
        [{ role: "user", content: prompt }],
        {
          resourceId: "telegram-bot",
          threadId: inputData.threadId,
          maxSteps: 10
        }
      );
      logger?.info(`\u2705 [processMediaUpload] AI agent processing complete`);
      const responseText = response.text;
      const mediaUrlMatch = responseText.match(/https:\/\/www\.facebook\.com\/[^\s]+/);
      const mediaUrl = mediaUrlMatch ? mediaUrlMatch[0] : void 0;
      const successMatch = responseText.match(/(\d+)\s*(?:grup)?\s*berhasil/i);
      const failMatch = responseText.match(/(\d+)\s*(?:grup)?\s*gagal/i);
      const totalMatch = responseText.match(/(\d+)\s*(?:total)?\s*grup/i);
      const hasError = responseText.toLowerCase().includes("error") || responseText.toLowerCase().includes("gagal") || responseText.toLowerCase().includes("tidak berhasil");
      const overallSuccess = mediaUrl !== void 0 && !hasError;
      logger?.info(`\u{1F4CA} [processMediaUpload] AI Results for ${mediaType}:`, {
        overallSuccess,
        hasMediaUrl: !!mediaUrl,
        hasError
      });
      return {
        success: overallSuccess,
        mediaUrl,
        shareResults: {
          totalGroups: totalMatch ? parseInt(totalMatch[1]) : 0,
          successCount: successMatch ? parseInt(successMatch[1]) : 0,
          failCount: failMatch ? parseInt(failMatch[1]) : 0
        },
        message: responseText
      };
    } catch (error) {
      logger?.error(`\u274C [processMediaUpload] AI Error for ${mediaType}, switching to fallback:`, error.message);
      logger?.warn("\u26A0\uFE0F Beralih ke mode fallback karena AI error");
      return await processMediaDirectly(inputData, mastra);
    }
  }
});
const facebookVideoWorkflow = createWorkflow({
  id: "facebook-video-workflow",
  // Keep same ID for backwards compatibility
  inputSchema: z.object({
    threadId: z.string().describe("Thread ID untuk memory management"),
    chatId: z.union([z.string(), z.number()]).describe("Telegram chat ID"),
    fileId: z.string().describe("Telegram file_id dari media (video atau photo)"),
    mediaType: z.enum(["video", "photo"]).default("video").describe("Type of media: video or photo"),
    title: z.string().describe("Judul/caption untuk media"),
    description: z.string().describe("Deskripsi/caption media dengan hashtags"),
    userName: z.string().optional().describe("Username pengirim")
  }),
  outputSchema: z.object({
    success: z.boolean(),
    mediaUrl: z.string().optional(),
    shareResults: z.object({
      totalGroups: z.number(),
      successCount: z.number(),
      failCount: z.number()
    }).optional(),
    message: z.string()
  })
}).then(processMediaUpload).commit();

if (!process.env.TELEGRAM_BOT_TOKEN) {
  console.warn(
    "Trying to initialize Telegram triggers without TELEGRAM_BOT_TOKEN. Can you confirm that the Telegram integration is configured correctly?"
  );
}
const userStates = /* @__PURE__ */ new Map();
const processingFiles = /* @__PURE__ */ new Map();
const PROCESSING_TIMEOUT = 5 * 60 * 1e3;
setInterval(() => {
  const now = Date.now();
  for (const [key, timestamp] of processingFiles.entries()) {
    if (now - timestamp > PROCESSING_TIMEOUT) {
      processingFiles.delete(key);
    }
  }
}, 10 * 60 * 1e3);
const ALLOWED_USER_IDS = /* @__PURE__ */ new Set([7390867903]);
function isUserAllowed(userId) {
  return ALLOWED_USER_IDS.has(userId);
}
async function sendTelegramMessage(chatId, text) {
  const token = process.env.TELEGRAM_BOT_TOKEN?.trim();
  if (!token) return;
  await fetch(`https://api.telegram.org/bot${token}/sendMessage`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      chat_id: chatId,
      text,
      parse_mode: "HTML"
    })
  });
}
function registerTelegramTrigger({
  triggerType,
  handler
}) {
  return [
    registerApiRoute("/webhooks/telegram/action", {
      method: "POST",
      handler: async (c) => {
        const mastra = c.get("mastra");
        const logger = mastra.getLogger();
        try {
          const payload = await c.req.json();
          logger?.info("\u{1F4DD} [Telegram] payload", payload);
          const message = payload.message;
          if (!message) {
            return c.text("OK", 200);
          }
          const chatId = message.chat.id;
          const userId = message.from?.id;
          const userName = message.from?.username || message.from?.first_name || "User";
          const text = message.text;
          const video = message.video;
          const photo = message.photo;
          if (userId && !isUserAllowed(userId)) {
            logger?.warn("\u{1F6AB} [Telegram] Unauthorized user blocked", {
              userId,
              userName,
              chatId
            });
            await sendTelegramMessage(
              chatId,
              "\u{1F6AB} <b>Akses Ditolak</b>\n\nMaaf, bot ini bersifat pribadi dan hanya dapat digunakan oleh pemiliknya.\n\nJika Anda memerlukan bot serupa, silakan hubungi pengembang."
            );
            return c.text("OK", 200);
          }
          if (text === "/start") {
            userStates.set(chatId, { step: "awaiting_media" });
            await sendTelegramMessage(
              chatId,
              "\u{1F3AC}\u{1F4F8} Selamat datang di Bot Upload Media ke Facebook!\n\nKirim <b>video</b> atau <b>foto</b> yang ingin kamu upload ke Facebook Page!"
            );
            return c.text("OK", 200);
          }
          const currentState = userStates.get(chatId);
          if (video) {
            logger?.info("\u{1F4F9} [Telegram] Video received", {
              fileId: video.file_id,
              fileName: video.file_name,
              fileSize: video.file_size
            });
            userStates.set(chatId, {
              step: "awaiting_title",
              mediaType: "video",
              mediaFileId: video.file_id,
              mediaFileName: video.file_name || `video_${Date.now()}.mp4`
            });
            await sendTelegramMessage(
              chatId,
              "\u2705 Video diterima!\n\n\u{1F4DD} Sekarang, kirim <b>judul</b> untuk video ini:"
            );
            return c.text("OK", 200);
          }
          if (photo && Array.isArray(photo) && photo.length > 0) {
            const largestPhoto = photo[photo.length - 1];
            logger?.info("\u{1F4F8} [Telegram] Photo received", {
              fileId: largestPhoto.file_id,
              fileSize: largestPhoto.file_size,
              width: largestPhoto.width,
              height: largestPhoto.height,
              totalSizes: photo.length
            });
            userStates.set(chatId, {
              step: "awaiting_title",
              mediaType: "photo",
              mediaFileId: largestPhoto.file_id,
              mediaFileName: `photo_${Date.now()}.jpg`
            });
            await sendTelegramMessage(
              chatId,
              "\u2705 Foto diterima!\n\n\u{1F4DD} Sekarang, kirim <b>caption</b> untuk foto ini:"
            );
            return c.text("OK", 200);
          }
          if (currentState && text) {
            if (currentState.step === "awaiting_title") {
              userStates.set(chatId, {
                ...currentState,
                step: "awaiting_description",
                title: text
              });
              const mediaLabel = currentState.mediaType === "photo" ? "foto" : "video";
              await sendTelegramMessage(
                chatId,
                `\u2705 ${currentState.mediaType === "photo" ? "Caption" : "Judul"} tersimpan!

\u{1F3F7}\uFE0F Sekarang, kirim <b>deskripsi/hashtags</b> untuk ${mediaLabel} ini:`
              );
              return c.text("OK", 200);
            } else if (currentState.step === "awaiting_description") {
              const description = text;
              const mediaType = currentState.mediaType || "video";
              const mediaLabel = mediaType === "photo" ? "foto" : "video";
              const fileKey = `${chatId}-${currentState.mediaFileId}`;
              const now = Date.now();
              if (processingFiles.has(fileKey)) {
                const processingTime = processingFiles.get(fileKey);
                const elapsedTime = now - processingTime;
                if (elapsedTime < PROCESSING_TIMEOUT) {
                  logger?.warn(`\u26A0\uFE0F [Telegram] Duplicate request detected dan diabaikan`, {
                    fileKey,
                    chatId,
                    mediaType,
                    elapsedTime: Math.floor(elapsedTime / 1e3) + "s"
                  });
                  await sendTelegramMessage(
                    chatId,
                    `\u26A0\uFE0F ${mediaLabel.charAt(0).toUpperCase() + mediaLabel.slice(1)} ini sedang diproses.

Mohon tunggu beberapa saat...`
                  );
                  return c.text("OK", 200);
                }
              }
              processingFiles.set(fileKey, now);
              logger?.info(`\u{1F512} [Telegram] Marking file as processing`, { fileKey, chatId, mediaType });
              try {
                let processingMessage = "";
                if (mediaType === "photo") {
                  processingMessage = "\u23F3 Sedang memproses foto...\n\n\u2022 Download foto dari Telegram\n\u2022 Upload ke Facebook Page\n\nMohon tunggu sebentar...";
                } else {
                  processingMessage = "\u23F3 Sedang memproses video...\n\n\u2022 Download video dari Telegram\n\u2022 Konversi video\n\u2022 Upload ke Facebook Page\n\u2022 Share ke grup-grup Facebook\n\nMohon tunggu sebentar...";
                }
                await sendTelegramMessage(chatId, processingMessage);
                const triggerType2 = mediaType === "photo" ? "telegram/photo" : "telegram/video";
                await handler(mastra, {
                  type: triggerType2,
                  params: {
                    userName,
                    chatId,
                    fileId: currentState.mediaFileId,
                    fileName: currentState.mediaFileName,
                    mediaType
                  },
                  payload: {
                    chatId,
                    fileId: currentState.mediaFileId,
                    fileName: currentState.mediaFileName,
                    mediaType,
                    title: currentState.title,
                    description,
                    userName
                  }
                });
              } finally {
                processingFiles.delete(fileKey);
                logger?.info(`\u{1F513} [Telegram] Cleared processing lock`, { fileKey, chatId, mediaType });
              }
              userStates.set(chatId, { step: "awaiting_media" });
              return c.text("OK", 200);
            }
          }
          if (!currentState || currentState.step === "awaiting_media") {
            await sendTelegramMessage(
              chatId,
              "\u{1F3AC}\u{1F4F8} Kirim <b>video</b> atau <b>foto</b> yang ingin kamu upload ke Facebook Page!\n\nAtau ketik /start untuk memulai ulang."
            );
          }
          return c.text("OK", 200);
        } catch (error) {
          logger?.error("Error handling Telegram webhook:", error);
          return c.text("Internal Server Error", 500);
        }
      }
    })
  ];
}

class ProductionPinoLogger extends MastraLogger {
  logger;
  constructor(options = {}) {
    super(options);
    this.logger = pino({
      name: options.name || "app",
      level: options.level || LogLevel.INFO,
      base: {},
      formatters: {
        level: (label, _number) => ({
          level: label
        })
      },
      timestamp: () => `,"time":"${new Date(Date.now()).toISOString()}"`
    });
  }
  debug(message, args = {}) {
    this.logger.debug(args, message);
  }
  info(message, args = {}) {
    this.logger.info(args, message);
  }
  warn(message, args = {}) {
    this.logger.warn(args, message);
  }
  error(message, args = {}) {
    this.logger.error(args, message);
  }
}
const mastra = new Mastra({
  storage: sharedPostgresStorage,
  // Register your workflows here
  workflows: {
    facebookVideoWorkflow
  },
  // Register your agents here
  agents: {
    facebookVideoAgent
  },
  mcpServers: {
    allTools: new MCPServer({
      name: "allTools",
      version: "1.0.0",
      tools: {}
    })
  },
  bundler: {
    // A few dependencies are not properly picked up by
    // the bundler if they are not added directly to the
    // entrypoint.
    externals: ["@slack/web-api", "inngest", "inngest/hono", "hono", "hono/streaming"],
    // sourcemaps are good for debugging.
    sourcemap: true
  },
  server: {
    host: "0.0.0.0",
    port: 5e3,
    middleware: [async (c, next) => {
      const mastra2 = c.get("mastra");
      const logger2 = mastra2?.getLogger();
      logger2?.debug("[Request]", {
        method: c.req.method,
        url: c.req.url
      });
      try {
        await next();
      } catch (error) {
        logger2?.error("[Response]", {
          method: c.req.method,
          url: c.req.url,
          error
        });
        if (error instanceof MastraError) {
          if (error.id === "AGENT_MEMORY_MISSING_RESOURCE_ID") {
            throw new NonRetriableError(error.message, {
              cause: error
            });
          }
        } else if (error instanceof z.ZodError) {
          throw new NonRetriableError(error.message, {
            cause: error
          });
        }
        throw error;
      }
    }],
    apiRoutes: [
      // ======================================================================
      // Health Check & Status Endpoints
      // ======================================================================
      {
        path: "/",
        method: "GET",
        createHandler: async () => {
          return async (c) => {
            const getPublicUrl2 = () => {
              if (process.env.PUBLIC_URL) {
                return process.env.PUBLIC_URL.trim();
              }
              if (process.env.REPLIT_DEV_DOMAIN) {
                return `https://${process.env.REPLIT_DEV_DOMAIN}`;
              }
              const replSlug = process.env.REPL_SLUG;
              const replOwner = process.env.REPL_OWNER;
              if (replSlug && replOwner) {
                return `https://${replSlug}.${replOwner}.replit.dev`;
              }
              return `http://localhost:${process.env.PORT || 5e3}`;
            };
            const publicUrl2 = getPublicUrl2();
            return c.json({
              status: "\u2705 Server Aktif",
              message: "Bot Telegram untuk Upload Video ke Facebook",
              publicUrl: publicUrl2,
              webhookUrl: `${publicUrl2}/webhooks/telegram/action`,
              endpoints: {
                telegram: "/webhooks/telegram/action",
                status: "/status",
                ping: "/ping",
                playground: "http://0.0.0.0:5000/",
                inngest: "/api/inngest"
              },
              instructions: `Untuk setup Telegram webhook, kunjungi:
https://api.telegram.org/bot<TOKEN>/setWebhook?url=${publicUrl2}/webhooks/telegram/action`
            });
          };
        }
      },
      {
        path: "/status",
        method: "GET",
        createHandler: async () => {
          return async (c) => {
            const getPublicUrl2 = () => {
              if (process.env.PUBLIC_URL) {
                return process.env.PUBLIC_URL.trim();
              }
              if (process.env.REPLIT_DEV_DOMAIN) {
                return `https://${process.env.REPLIT_DEV_DOMAIN}`;
              }
              const replSlug = process.env.REPL_SLUG;
              const replOwner = process.env.REPL_OWNER;
              if (replSlug && replOwner) {
                return `https://${replSlug}.${replOwner}.replit.dev`;
              }
              return `http://localhost:${process.env.PORT || 5e3}`;
            };
            const publicUrl2 = getPublicUrl2();
            return c.json({
              status: "online",
              publicUrl: publicUrl2,
              webhookUrl: `${publicUrl2}/webhooks/telegram/action`,
              timestamp: (/* @__PURE__ */ new Date()).toISOString()
            });
          };
        }
      },
      {
        path: "/ping",
        method: "GET",
        createHandler: async () => {
          return async (c) => {
            return c.json({
              status: "pong",
              uptime: process.uptime(),
              timestamp: (/* @__PURE__ */ new Date()).toISOString(),
              message: "Server is alive"
            });
          };
        }
      },
      // ======================================================================
      // Inngest Integration Endpoint
      // ======================================================================
      // This API route is used to register the Mastra workflow (inngest function) on the inngest server
      {
        path: "/api/inngest",
        method: "ALL",
        createHandler: async ({
          mastra: mastra2
        }) => inngestServe({
          mastra: mastra2,
          inngest
        })
        // The inngestServe function integrates Mastra workflows with Inngest by:
        // 1. Creating Inngest functions for each workflow with unique IDs (workflow.${workflowId})
        // 2. Setting up event handlers that:
        //    - Generate unique run IDs for each workflow execution
        //    - Create an InngestExecutionEngine to manage step execution
        //    - Handle workflow state persistence and real-time updates
        // 3. Establishing a publish-subscribe system for real-time monitoring
        //    through the workflow:${workflowId}:${runId} channel
      },
      // ======================================================================
      // Connector Webhook Triggers
      // ======================================================================
      // Register your connector webhook handlers here using the spread operator.
      // Each connector trigger should be defined in src/triggers/{connectorName}Triggers.ts
      //
      // PATTERN FOR ADDING A NEW CONNECTOR TRIGGER:
      //
      // 1. Create a trigger file: src/triggers/{connectorName}Triggers.ts
      //    (See src/triggers/exampleConnectorTrigger.ts for a complete example)
      //
      // 2. Create a workflow: src/mastra/workflows/{connectorName}Workflow.ts
      //    (See src/mastra/workflows/linearIssueWorkflow.ts for an example)
      //
      // 3. Import both in this file:
      //    ```typescript
      //    import { register{ConnectorName}Trigger } from "../triggers/{connectorName}Triggers";
      //    import { {connectorName}Workflow } from "./workflows/{connectorName}Workflow";
      //    ```
      //
      // 4. Register the trigger in the apiRoutes array below:
      //    ```typescript
      //    ...register{ConnectorName}Trigger({
      //      triggerType: "{connector}/{event.type}",
      //      handler: async (mastra, triggerInfo) => {
      //        const logger = mastra.getLogger();
      //        logger?.info("🎯 [{Connector} Trigger] Processing {event}", {
      //          // Log relevant fields from triggerInfo.params
      //        });
      //
      //        // Create a unique thread ID for this event
      //        const threadId = `{connector}-{event}-${triggerInfo.params.someUniqueId}`;
      //
      //        // Start the workflow
      //        const run = await {connectorName}Workflow.createRunAsync();
      //        return await run.start({
      //          inputData: {
      //            threadId,
      //            ...triggerInfo.params,
      //          },
      //        });
      //      }
      //    })
      //    ```
      //
      // ======================================================================
      // EXAMPLE: Linear Issue Creation Webhook
      // ======================================================================
      // Uncomment to enable Linear webhook integration:
      //
      // ...registerLinearTrigger({
      //   triggerType: "linear/issue.created",
      //   handler: async (mastra, triggerInfo) => {
      //     // Extract what you need from the full payload
      //     const data = triggerInfo.payload?.data || {};
      //     const title = data.title || "Untitled";
      //
      //     // Start your workflow
      //     const run = await exampleWorkflow.createRunAsync();
      //     return await run.start({
      //       inputData: {
      //         message: `Linear Issue: ${title}`,
      //         includeAnalysis: true,
      //       }
      //     });
      //   }
      // }),
      //
      // To activate:
      // 1. Uncomment the code above
      // 2. Import at the top: import { registerLinearTrigger } from "../triggers/exampleConnectorTrigger";
      //
      // ======================================================================
      // Add more connector triggers below using the same pattern
      // ...registerGithubTrigger({ ... }),
      // ...registerSlackTrigger({ ... }),
      // ...registerStripeWebhook({ ... }),
      // Telegram trigger for media upload to Facebook (handles both video and photo)
      ...registerTelegramTrigger({
        triggerType: "telegram/media",
        handler: async (mastra2, triggerInfo) => {
          const logger2 = mastra2.getLogger();
          const mediaType = triggerInfo.params.mediaType || "video";
          const mediaLabel = mediaType === "photo" ? "photo" : "video";
          logger2?.info(`\u{1F3AF} [Telegram Trigger] Processing ${mediaLabel} upload`, {
            chatId: triggerInfo.params.chatId,
            fileId: triggerInfo.params.fileId,
            mediaType
          });
          const threadId = `telegram-${mediaType}-${triggerInfo.params.chatId}-${Date.now()}`;
          const run = await facebookVideoWorkflow.createRunAsync();
          await run.start({
            inputData: {
              threadId,
              chatId: triggerInfo.payload.chatId,
              fileId: triggerInfo.payload.fileId,
              mediaType: triggerInfo.payload.mediaType || "video",
              title: triggerInfo.payload.title,
              description: triggerInfo.payload.description,
              userName: triggerInfo.payload.userName
            }
          });
        }
      })
    ]
  },
  logger: process.env.NODE_ENV === "production" ? new ProductionPinoLogger({
    name: "Mastra",
    level: "info"
  }) : new PinoLogger({
    name: "Mastra",
    level: "info"
  })
});
if (Object.keys(mastra.getWorkflows()).length > 1) {
  throw new Error("More than 1 workflows found. Currently, more than 1 workflows are not supported in the UI, since doing so will cause app state to be inconsistent.");
}
if (Object.keys(mastra.getAgents()).length > 1) {
  throw new Error("More than 1 agents found. Currently, more than 1 agents are not supported in the UI, since doing so will cause app state to be inconsistent.");
}
const getPublicUrl = () => {
  if (process.env.PUBLIC_URL) {
    return process.env.PUBLIC_URL.trim();
  }
  if (process.env.REPLIT_DEV_DOMAIN) {
    return `https://${process.env.REPLIT_DEV_DOMAIN}`;
  }
  const replSlug = process.env.REPL_SLUG;
  const replOwner = process.env.REPL_OWNER;
  if (replSlug && replOwner) {
    return `https://${replSlug}.${replOwner}.replit.dev`;
  }
  return `http://localhost:${process.env.PORT || 5e3}`;
};
const publicUrl = getPublicUrl();
const logger = mastra.getLogger();
logger?.info("\u{1F680} ========================================");
logger?.info("\u{1F3AC} Bot Telegram untuk Upload Video ke Facebook");
logger?.info("\u{1F680} ========================================");
logger?.info(`\u{1F30D} URL Publik AKTIF: ${publicUrl}`);
logger?.info(`\u{1F4E1} Webhook Telegram: ${publicUrl}/webhooks/telegram/action`);
logger?.info(`\u{1F4CA} Status Endpoint: ${publicUrl}/status`);
logger?.info(`\u2764\uFE0F  Keep-Alive: ${publicUrl}/ping`);
logger?.info("\u{1F680} ========================================");
logger?.info("\u{1F4DD} Setup Telegram Webhook:");
logger?.info(`   https://api.telegram.org/bot<TOKEN>/setWebhook?url=${publicUrl}/webhooks/telegram/action`);
logger?.info("\u{1F4DD} Verifikasi Webhook:");
logger?.info(`   https://api.telegram.org/bot<TOKEN>/getWebhookInfo`);
logger?.info("\u{1F680} ========================================");
const telegramToken = process.env.TELEGRAM_BOT_TOKEN?.trim();
const autoWebhook = process.env.AUTO_WEBHOOK !== "false";
if (telegramToken && autoWebhook && publicUrl.startsWith("http")) {
  const webhookUrl = `${publicUrl}/webhooks/telegram/action`;
  const setWebhookUrl = `https://api.telegram.org/bot${telegramToken}/setWebhook?url=${webhookUrl}`;
  logger?.info("\u{1F504} Auto-setting Telegram webhook...");
  logger?.info(`   Webhook URL: ${webhookUrl}`);
  logger?.info(`   Bot Token Length: ${telegramToken.length} characters`);
  fetch(setWebhookUrl).then((res) => res.json()).then((data) => {
    if (data.ok) {
      logger?.info("\u2705 Telegram webhook berhasil di-set!");
      logger?.info(`   Webhook URL: ${webhookUrl}`);
      fetch(`https://api.telegram.org/bot${telegramToken}/getWebhookInfo`).then((res) => res.json()).then((info) => {
        logger?.info("\u{1F4CA} Webhook Info:", info.result);
      }).catch((err) => logger?.warn("\u26A0\uFE0F  Gagal verifikasi webhook:", err.message));
    } else {
      logger?.warn("\u26A0\uFE0F  Gagal set webhook:", data);
    }
  }).catch((err) => {
    logger?.warn("\u26A0\uFE0F  Gagal menghubungi Telegram API:", err.message);
    logger?.info("\u{1F4A1} Silakan set webhook manual dengan URL di atas");
  });
} else if (telegramToken && !autoWebhook) {
  logger?.info("\u2699\uFE0F  AUTO_WEBHOOK disabled. Set webhook manual jika diperlukan");
  logger?.info(`   https://api.telegram.org/bot<TOKEN>/setWebhook?url=${publicUrl}/webhooks/telegram/action`);
}

export { mastra };
